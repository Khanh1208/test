// In-memory database cho dữ liệu người dùng với JSON persistence
const fs = require('fs');
const path = require('path');
const userDatabase = new Map();
const config = require('../config');

// Đường dẫn file JSON
const DATABASE_FILE = path.join(__dirname, '..', 'player.json');

/**
 * Load dữ liệu từ file JSON
 */
function loadDatabase() {
    try {
        if (fs.existsSync(DATABASE_FILE)) {
            const data = fs.readFileSync(DATABASE_FILE, 'utf8');
            const jsonData = JSON.parse(data);
            
            // Chuyển đổi object thành Map
            for (const [userId, userData] of Object.entries(jsonData)) {
                userDatabase.set(userId, userData);
            }
            
            console.log(`📊 Đã load ${userDatabase.size} người dùng từ player.json`);
        }
    } catch (error) {
        console.error('❌ Lỗi khi load database:', error);
    }
}

/**
 * Lưu dữ liệu vào file JSON
 */
function saveDatabase() {
    try {
        // Chuyển đổi Map thành object
        const dataToSave = {};
        for (const [userId, userData] of userDatabase.entries()) {
            dataToSave[userId] = userData;
        }
        
        fs.writeFileSync(DATABASE_FILE, JSON.stringify(dataToSave, null, 2), 'utf8');
    } catch (error) {
        console.error('❌ Lỗi khi lưu database:', error);
    }
}

/**
 * Khởi tạo dữ liệu người dùng mặc định
 */
function createDefaultUser(userId) {
    return {
        userId: userId,
        realmId: 0, // Bắt đầu từ Phàm Nhân
        experience: 0,
        level: 1,
        
        // Tài nguyên
        resources: {
            linhKhi: config.CULTIVATION.STARTING_RESOURCES.LINH_KHI,
            linhThach: config.CULTIVATION.STARTING_RESOURCES.LINH_THACH,
            danDuoc: config.CULTIVATION.STARTING_RESOURCES.DAN_DUOC
        },
        
        // Thuộc tính cơ bản
        attributes: {
            baseAtk: 50,       // Sức tấn công cơ bản
            baseHp: 100,       // Máu cơ bản  
            baseDefense: 50,   // Giáp cơ bản
            baseMana: 50       // Mana cơ bản
        },
        
        // Kho đồ - lưu dạng {itemId: quantity}
        inventory: {},
        
        // Trang bị hiện tại
        equipment: {
            weapon: null,      // ID vũ khí
            armor: null,       // ID áo giáp
            treasure: null     // ID bảo vật
        },
        
        // Thống kê
        stats: {
            totalTraining: 0,
            totalBreakthroughs: 0,
            totalCombats: 0,
            winsCount: 0,
            lossesCount: 0,
            consecutiveWins: 0
        },
        
        // Thời gian
        timestamps: {
            lastTraining: 0,
            lastBreakthrough: 0,
            lastCombat: 0,
            joined: Date.now(),
            lastTrainingReset: Date.now() // Để track reset hàng ngày
        },
        
        // Giới hạn hàng ngày
        dailyLimits: {
            trainingCount: 0, // Số lần tu luyện hôm nay
            lastResetDate: new Date().toDateString() // Ngày reset cuối cùng
        },
        
        // Cài đặt
        settings: {
            autoBreakthrough: false,
            showDetailedStats: true
        }
    };
}

/**
 * Kiểm tra và reset daily limits nếu cần
 */
function checkAndResetDailyLimits(user) {
    const today = new Date().toDateString();
    if (user.dailyLimits && user.dailyLimits.lastResetDate !== today) {
        user.dailyLimits.trainingCount = 0;
        user.dailyLimits.lastResetDate = today;
        user.timestamps.lastTrainingReset = Date.now();
        saveUser(user);
    }
    return user;
}

/**
 * Lấy dữ liệu người dùng (chỉ tạo mới nếu đã đăng ký)
 */
function getUser(userId) {
    if (!userDatabase.has(userId)) {
        userDatabase.set(userId, createDefaultUser(userId));
    }
    const user = userDatabase.get(userId);
    
    // Tự động cập nhật level dựa trên kinh nghiệm hiện tại
    if (user.experience > 0) {
        const realms = require('./realms');
        user.level = realms.calculateLevel(user.experience, user.realmId);
    }
    
    return checkAndResetDailyLimits(user);
}

/**
 * Lấy dữ liệu người dùng an toàn (không tự động tạo mới)
 */
function getUserSafe(userId) {
    const user = userDatabase.get(userId);
    if (user && !user.attributes) {
        // Cập nhật user cũ với thuộc tính mới
        user.attributes = {
            baseAtk: 50,
            baseHp: 100,
            baseDefense: 50,
            baseMana: 50
        };
        saveUser(user);
    }
    
    // Cập nhật user cũ với daily limits nếu chưa có
    if (user && !user.dailyLimits) {
        user.dailyLimits = {
            trainingCount: 0,
            lastResetDate: new Date().toDateString()
        };
        if (!user.timestamps.lastTrainingReset) {
            user.timestamps.lastTrainingReset = Date.now();
        }
        saveUser(user);
    }
    
    return user || null;
}

/**
 * Cập nhật dữ liệu người dùng
 */
function updateUser(userId, userData) {
    userDatabase.set(userId, userData);
    return userData;
}

/**
 * Lưu dữ liệu người dùng (wrapper cho updateUser)
 */
function saveUser(userData) {
    const result = updateUser(userData.userId, userData);
    saveDatabase(); // Tự động lưu vào file JSON
    return result;
}

/**
 * Kiểm tra người dùng có tồn tại không
 */
function userExists(userId) {
    return userDatabase.has(userId);
}

/**
 * Xóa dữ liệu người dùng
 */
function deleteUser(userId) {
    const result = userDatabase.delete(userId);
    saveDatabase(); // Tự động lưu vào file JSON
    return result;
}

/**
 * Lấy tất cả người dùng (cho leaderboard)
 */
function getAllUsers() {
    return Array.from(userDatabase.values());
}

/**
 * Lấy top người dùng theo tiêu chí
 */
function getTopUsers(sortBy = 'realmId', limit = 10) {
    const users = getAllUsers();
    
    users.sort((a, b) => {
        if (sortBy === 'realmId') {
            // Sắp xếp theo cảnh giới, sau đó theo kinh nghiệm
            if (a.realmId !== b.realmId) {
                return b.realmId - a.realmId;
            }
            return b.experience - a.experience;
        } else if (sortBy === 'experience') {
            return b.experience - a.experience;
        } else if (sortBy === 'level') {
            return b.level - a.level;
        } else if (sortBy === 'wins') {
            return b.stats.winsCount - a.stats.winsCount;
        }
        return 0;
    });
    
    return users.slice(0, limit);
}

/**
 * Thêm kinh nghiệm cho người dùng
 */
function addExperience(userId, amount) {
    const user = getUser(userId);
    user.experience += amount;
    return saveUser(user);
}

/**
 * Thêm tài nguyên cho người dùng
 */
function addResources(userId, resources) {
    const user = getUser(userId);
    
    if (resources.linhKhi) user.resources.linhKhi += resources.linhKhi;
    if (resources.linhThach) user.resources.linhThach += resources.linhThach;
    if (resources.danDuoc) user.resources.danDuoc += resources.danDuoc;
    
    // Đảm bảo không âm
    user.resources.linhKhi = Math.max(0, user.resources.linhKhi);
    user.resources.linhThach = Math.max(0, user.resources.linhThach);
    user.resources.danDuoc = Math.max(0, user.resources.danDuoc);
    
    return saveUser(user);
}

/**
 * Trừ tài nguyên của người dùng
 */
function spendResources(userId, resources) {
    const user = getUser(userId);
    
    // Kiểm tra đủ tài nguyên không
    if (resources.linhKhi && user.resources.linhKhi < resources.linhKhi) return false;
    if (resources.linhThach && user.resources.linhThach < resources.linhThach) return false;
    if (resources.danDuoc && user.resources.danDuoc < resources.danDuoc) return false;
    
    // Trừ tài nguyên
    if (resources.linhKhi) user.resources.linhKhi -= resources.linhKhi;
    if (resources.linhThach) user.resources.linhThach -= resources.linhThach;
    if (resources.danDuoc) user.resources.danDuoc -= resources.danDuoc;
    
    saveUser(user);
    return true;
}

/**
 * Cập nhật thống kê chiến đấu
 */
function updateCombatStats(userId, isWin) {
    const user = getUser(userId);
    
    user.stats.totalCombats++;
    
    if (isWin) {
        user.stats.winsCount++;
        user.stats.consecutiveWins++;
    } else {
        user.stats.lossesCount++;
        user.stats.consecutiveWins = 0;
    }
    
    return saveUser(user);
}

/**
 * Reset database (chỉ dùng cho testing)
 */
function resetDatabase() {
    userDatabase.clear();
}

/**
 * Thêm vật phẩm vào kho
 */
function addItemToInventory(userId, itemId, quantity = 1) {
    const user = getUserSafe(userId);
    if (!user) return false;
    
    if (!user.inventory[itemId]) {
        user.inventory[itemId] = 0;
    }
    
    user.inventory[itemId] += quantity;
    saveUser(user);
    return true;
}

/**
 * Xóa vật phẩm khỏi kho
 */
function removeItemFromInventory(userId, itemId, quantity = 1) {
    const user = getUserSafe(userId);
    if (!user || !user.inventory[itemId]) return false;
    
    if (user.inventory[itemId] < quantity) return false;
    
    user.inventory[itemId] -= quantity;
    if (user.inventory[itemId] <= 0) {
        delete user.inventory[itemId];
    }
    
    saveUser(user);
    return true;
}

/**
 * Kiểm tra có vật phẩm trong kho không
 */
function hasItemInInventory(userId, itemId, quantity = 1) {
    const user = getUserSafe(userId);
    if (!user) return false;
    
    return user.inventory[itemId] >= quantity;
}

/**
 * Lấy tất cả vật phẩm trong kho
 */
function getUserInventory(userId) {
    const user = getUserSafe(userId);
    if (!user) return {};
    
    return user.inventory;
}

/**
 * Trang bị vật phẩm
 */
function equipItem(userId, itemId, slot) {
    const user = getUserSafe(userId);
    if (!user || !hasItemInInventory(userId, itemId)) return false;
    
    // Bỏ trang bị cũ (nếu có)
    if (user.equipment[slot]) {
        addItemToInventory(userId, user.equipment[slot], 1);
    }
    
    // Trang bị mới
    user.equipment[slot] = itemId;
    removeItemFromInventory(userId, itemId, 1);
    saveUser(user);
    return true;
}

/**
 * Bỏ trang bị
 */
function unequipItem(userId, slot) {
    const user = getUserSafe(userId);
    if (!user || !user.equipment[slot]) return false;
    
    // Trả về kho
    addItemToInventory(userId, user.equipment[slot], 1);
    user.equipment[slot] = null;
    saveUser(user);
    return true;
}

/**
 * Lấy thông tin trang bị
 */
function getUserEquipment(userId) {
    const user = getUserSafe(userId);
    if (!user) return {};
    
    return user.equipment;
}

/**
 * Tính toán thuộc tính tổng cộng (cơ bản + cảnh giới + trang bị)
 */
function calculateTotalAttributes(userId) {
    const user = getUserSafe(userId);
    if (!user) return null;
    
    // Thuộc tính cơ bản
    let totalAtk = user.attributes.baseAtk;
    let totalHp = user.attributes.baseHp;
    let totalDefense = user.attributes.baseDefense;
    let totalMana = user.attributes.baseMana;
    
    // Bonus theo cảnh giới (mỗi cảnh giới tăng 20% thuộc tính)
    const realmMultiplier = 1 + (user.realmId * 0.2);
    totalAtk = Math.floor(totalAtk * realmMultiplier);
    totalHp = Math.floor(totalHp * realmMultiplier);
    totalDefense = Math.floor(totalDefense * realmMultiplier);
    totalMana = Math.floor(totalMana * realmMultiplier);
    
    // Bonus từ trang bị
    if (user.equipment.weapon) {
        const { getItemById } = require('./items');
        const weapon = getItemById(user.equipment.weapon);
        if (weapon && weapon.power) {
            totalAtk += weapon.power;
        }
    }
    
    if (user.equipment.armor) {
        const { getItemById } = require('./items');
        const armor = getItemById(user.equipment.armor);
        if (armor && armor.defense) {
            totalDefense += armor.defense;
        }
    }
    
    if (user.equipment.treasure) {
        const { getItemById } = require('./items');
        const treasure = getItemById(user.equipment.treasure);
        if (treasure && treasure.effect && treasure.value) {
            switch (treasure.effect) {
                case 'mana_boost':
                    totalMana += treasure.value;
                    break;
                case 'hp_boost':
                    totalHp += treasure.value;
                    break;
                case 'qi_regen':
                    // Hiệu ứng đặc biệt, không ảnh hưởng thuộc tính chiến đấu
                    break;
            }
        }
    }
    
    return {
        atk: totalAtk,
        hp: totalHp,
        defense: totalDefense,
        mana: totalMana,
        // Hiển thị chi tiết
        breakdown: {
            base: {
                atk: user.attributes.baseAtk,
                hp: user.attributes.baseHp,
                defense: user.attributes.baseDefense,
                mana: user.attributes.baseMana
            },
            realmBonus: {
                multiplier: realmMultiplier,
                atk: Math.floor(user.attributes.baseAtk * realmMultiplier) - user.attributes.baseAtk,
                hp: Math.floor(user.attributes.baseHp * realmMultiplier) - user.attributes.baseHp,
                defense: Math.floor(user.attributes.baseDefense * realmMultiplier) - user.attributes.baseDefense,
                mana: Math.floor(user.attributes.baseMana * realmMultiplier) - user.attributes.baseMana
            },
            equipmentBonus: {
                atk: totalAtk - Math.floor(user.attributes.baseAtk * realmMultiplier),
                defense: totalDefense - Math.floor(user.attributes.baseDefense * realmMultiplier),
                mana: totalMana - Math.floor(user.attributes.baseMana * realmMultiplier)
            }
        }
    };
}

/**
 * Lấy thống kê database
 */
function getDatabaseStats() {
    return {
        totalUsers: userDatabase.size,
        totalExperience: getAllUsers().reduce((sum, user) => sum + user.experience, 0),
        averageRealm: getAllUsers().reduce((sum, user) => sum + user.realmId, 0) / userDatabase.size || 0
    };
}

// Load dữ liệu khi khởi động
loadDatabase();

// Lưu dữ liệu định kỳ mỗi 5 phút
setInterval(() => {
    saveDatabase();
    console.log('💾 Auto-save database completed');
}, 5 * 60 * 1000);

// Lưu dữ liệu khi process kết thúc
process.on('SIGINT', () => {
    console.log('🛑 Bot đang tắt, đang lưu dữ liệu...');
    saveDatabase();
    process.exit(0);
});

process.on('SIGTERM', () => {
    saveDatabase();
    process.exit(0);
});

module.exports = {
    getUser,
    getUserSafe,
    updateUser,
    saveUser,
    userExists,
    deleteUser,
    getAllUsers,
    getTopUsers,
    addExperience,
    addResources,
    spendResources,
    updateCombatStats,
    resetDatabase,
    getDatabaseStats,
    loadDatabase,
    saveDatabase,
    // Inventory functions
    addItemToInventory,
    removeItemFromInventory,
    hasItemInInventory,
    getUserInventory,
    equipItem,
    unequipItem,
    getUserEquipment,
    // Attributes functions
    calculateTotalAttributes,
    // Daily limits functions
    checkAndResetDailyLimits
};
