// Hệ thống vật phẩm cho bot tu tiên
const ITEM_TYPES = {
    WEAPON: 'weapon',
    ARMOR: 'armor',
    PILL: 'pill',
    MATERIAL: 'material',
    TREASURE: 'treasure'
};

const ITEM_RARITY = {
    COMMON: { name: 'Thường', color: 0x808080, emoji: '⚪' },
    UNCOMMON: { name: 'Không Thường', color: 0x00FF00, emoji: '🟢' },
    RARE: { name: 'Hiếm', color: 0x0080FF, emoji: '🔵' },
    EPIC: { name: 'Sử Thi', color: 0x8000FF, emoji: '🟣' },
    LEGENDARY: { name: 'Huyền Thoại', color: 0xFF8000, emoji: '🟠' },
    DIVINE: { name: 'Thần Khí', color: 0xFFD700, emoji: '🟡' }
};

// Danh sách vật phẩm
const ITEMS = {
    // Vũ khí
    1: {
        id: 1,
        name: 'Kiếm Thép',
        type: ITEM_TYPES.WEAPON,
        rarity: ITEM_RARITY.COMMON,
        power: 100,
        price: 1000,
        description: 'Một thanh kiếm bằng thép thường, phù hợp cho người mới tu luyện.',
        emoji: '⚔️'
    },
    2: {
        id: 2,
        name: 'Kiếm Linh Khí',
        type: ITEM_TYPES.WEAPON,
        rarity: ITEM_RARITY.UNCOMMON,
        power: 500,
        price: 5000,
        description: 'Thanh kiếm được tẩm linh khí, tăng sức mạnh đáng kể.',
        emoji: '🗡️'
    },
    3: {
        id: 3,
        name: 'Kiếm Phá Thiên',
        type: ITEM_TYPES.WEAPON,
        rarity: ITEM_RARITY.LEGENDARY,
        power: 10000,
        price: 100000,
        description: 'Thần kiếm có thể phá vỡ bầu trời, chỉ cao thủ mới có thể sử dụng.',
        emoji: '⚡'
    },

    // Áo giáp
    10: {
        id: 10,
        name: 'Áo Giáp Da',
        type: ITEM_TYPES.ARMOR,
        rarity: ITEM_RARITY.COMMON,
        defense: 50,
        price: 800,
        description: 'Áo giáp da đơn giản, bảo vệ cơ bản.',
        emoji: '🛡️'
    },
    11: {
        id: 11,
        name: 'Áo Giáp Linh Khí',
        type: ITEM_TYPES.ARMOR,
        rarity: ITEM_RARITY.RARE,
        defense: 2000,
        price: 20000,
        description: 'Áo giáp được chế tác từ linh khí, phòng thủ cực tốt.',
        emoji: '🛡️'
    },

    // Đan dược
    20: {
        id: 20,
        name: 'Hồi Khí Đan',
        type: ITEM_TYPES.PILL,
        rarity: ITEM_RARITY.COMMON,
        effect: 'restore_qi',
        value: 1000,
        price: 500,
        description: 'Viên đan phục hồi linh khí.',
        emoji: '💊'
    },
    21: {
        id: 21,
        name: 'Tăng Tu Vi Đan',
        type: ITEM_TYPES.PILL,
        rarity: ITEM_RARITY.RARE,
        effect: 'boost_exp',
        value: 5000,
        price: 10000,
        description: 'Viên đan giúp tăng kinh nghiệm tu luyện.',
        emoji: '💊'
    },

    // Nguyên liệu
    30: {
        id: 30,
        name: 'Linh Thảo',
        type: ITEM_TYPES.MATERIAL,
        rarity: ITEM_RARITY.COMMON,
        price: 100,
        description: 'Loại thảo dược thường gặp, dùng để luyện đan.',
        emoji: '🌿'
    },
    31: {
        id: 31,
        name: 'Thiên Linh Thảo',
        type: ITEM_TYPES.MATERIAL,
        rarity: ITEM_RARITY.LEGENDARY,
        price: 50000,
        description: 'Thảo dược thiên nhiên hiếm có, có thể luyện thành đan dược thần kỳ.',
        emoji: '🌟'
    },

    // Bảo vật
    40: {
        id: 40,
        name: 'Nhẫn Linh Khí',
        type: ITEM_TYPES.TREASURE,
        rarity: ITEM_RARITY.EPIC,
        effect: 'qi_regen',
        value: 50,
        price: 25000,
        description: 'Chiếc nhẫn thần bí, tự động hồi phục linh khí.',
        emoji: '💍'
    },
    41: {
        id: 41,
        name: 'Nhẫn Mana',
        type: ITEM_TYPES.TREASURE,
        rarity: ITEM_RARITY.RARE,
        effect: 'mana_boost',
        value: 100,
        price: 15000,
        description: 'Nhẫn tăng cường mana, giúp thi triển thuật pháp mạnh mẽ hơn.',
        emoji: '🔮'
    },
    42: {
        id: 42,
        name: 'Bùa Hộ Mệnh',
        type: ITEM_TYPES.TREASURE,
        rarity: ITEM_RARITY.LEGENDARY,
        effect: 'hp_boost',
        value: 200,
        price: 30000,
        description: 'Bùa hộ mệnh cổ xưa, tăng sinh mệnh đáng kể.',
        emoji: '🛡️'
    }
};

/**
 * Lấy thông tin vật phẩm theo ID
 */
function getItemById(itemId) {
    return ITEMS[itemId] || null;
}

/**
 * Lấy tất cả vật phẩm
 */
function getAllItems() {
    return Object.values(ITEMS);
}

/**
 * Lấy vật phẩm theo loại
 */
function getItemsByType(type) {
    return Object.values(ITEMS).filter(item => item.type === type);
}

/**
 * Lấy vật phẩm theo độ hiếm
 */
function getItemsByRarity(rarity) {
    return Object.values(ITEMS).filter(item => item.rarity.name === rarity);
}

/**
 * Format hiển thị vật phẩm
 */
function formatItem(item, quantity = 1) {
    const quantityText = quantity > 1 ? ` x${quantity}` : '';
    return `${item.rarity.emoji} ${item.emoji} **${item.name}**${quantityText}`;
}

/**
 * Tạo embed thông tin vật phẩm
 */
function createItemEmbed(item) {
    const embed = {
        color: item.rarity.color,
        title: `${item.emoji} ${item.name}`,
        description: item.description,
        fields: [
            {
                name: '🏷️ Loại',
                value: getTypeDisplayName(item.type),
                inline: true
            },
            {
                name: '⭐ Độ Hiếm',
                value: `${item.rarity.emoji} ${item.rarity.name}`,
                inline: true
            },
            {
                name: '💰 Giá',
                value: `${item.price.toLocaleString()} Linh Thạch`,
                inline: true
            }
        ]
    };

    // Thêm thông tin đặc biệt theo loại
    if (item.power) {
        embed.fields.push({
            name: '⚔️ Sức Mạnh',
            value: `+${item.power.toLocaleString()}`,
            inline: true
        });
    }
    
    if (item.defense) {
        embed.fields.push({
            name: '🛡️ Phòng Thủ',
            value: `+${item.defense.toLocaleString()}`,
            inline: true
        });
    }

    if (item.effect && item.value) {
        embed.fields.push({
            name: '✨ Hiệu Ứng',
            value: getEffectDescription(item.effect, item.value),
            inline: true
        });
    }

    return embed;
}

/**
 * Lấy tên hiển thị của loại vật phẩm
 */
function getTypeDisplayName(type) {
    const typeNames = {
        [ITEM_TYPES.WEAPON]: '⚔️ Vũ Khí',
        [ITEM_TYPES.ARMOR]: '🛡️ Áo Giáp',
        [ITEM_TYPES.PILL]: '💊 Đan Dược',
        [ITEM_TYPES.MATERIAL]: '🌿 Nguyên Liệu',
        [ITEM_TYPES.TREASURE]: '💎 Bảo Vật'
    };
    return typeNames[type] || 'Không xác định';
}

/**
 * Lấy mô tả hiệu ứng
 */
function getEffectDescription(effect, value) {
    const effects = {
        'restore_qi': `Phục hồi ${value} Linh Khí`,
        'boost_exp': `Tăng ${value} EXP`,
        'qi_regen': `Hồi ${value} Linh Khí/giờ`
    };
    return effects[effect] || 'Hiệu ứng đặc biệt';
}

module.exports = {
    ITEM_TYPES,
    ITEM_RARITY,
    ITEMS,
    getItemById,
    getAllItems,
    getItemsByType,
    getItemsByRarity,
    formatItem,
    createItemEmbed,
    getTypeDisplayName,
    getEffectDescription
};