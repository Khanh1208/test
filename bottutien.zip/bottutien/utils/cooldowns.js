const config = require("../config");

// Map lưu trữ cooldown cho từng loại hoạt động
const cooldowns = new Map();

/**
 * Kiểm tra cooldown cho một hoạt động
 */
function checkCooldown(userId, action) {
    const key = `${userId}-${action}`;
    const now = Date.now();

    if (!cooldowns.has(key)) {
        return { onCooldown: false, timeLeft: 0 };
    }

    const cooldownEnd = cooldowns.get(key);
    const timeLeft = cooldownEnd - now;

    if (timeLeft <= 0) {
        cooldowns.delete(key);
        return { onCooldown: false, timeLeft: 0 };
    }

    return { onCooldown: true, timeLeft };
}

/**
 * Đặt cooldown cho một hoạt động
 */
function setCooldown(userId, action, duration) {
    const key = `${userId}-${action}`;
    const cooldownEnd = Date.now() + duration;
    cooldowns.set(key, cooldownEnd);
}

/**
 * Xóa cooldown cho một hoạt động
 */
function removeCooldown(userId, action) {
    const key = `${userId}-${action}`;
    cooldowns.delete(key);
}

/**
 * Lấy thời gian cooldown mặc định cho từng loại hoạt động
 */
function getDefaultCooldown(action) {
    switch (action) {
        case "training":
            return config.CULTIVATION.TRAINING_COOLDOWN;
        case "breakthrough":
            return config.CULTIVATION.BREAKTHROUGH_COOLDOWN;
        case "combat":
            return config.CULTIVATION.COMBAT_COOLDOWN;
        default:
            return 0;
    }
}

/**
 * Format thời gian còn lại thành chuỗi dễ đọc
 */
function formatTimeLeft(milliseconds) {
    const seconds = Math.floor(milliseconds / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) {
        return `${days} ngày ${hours % 24} giờ`;
    } else if (hours > 0) {
        return `${hours} giờ ${minutes % 60} phút`;
    } else if (minutes > 0) {
        return `${minutes} phút ${seconds % 60} giây`;
    } else {
        return `${seconds} giây`;
    }
}

/**
 * Kiểm tra và đặt cooldown cho tu luyện
 */
function handleTrainingCooldown(userId) {
    const cooldownCheck = checkCooldown(userId, "training");
    if (cooldownCheck.onCooldown) {
        return {
            canProceed: false,
            message: `⏰ Bạn cần nghỉ ngơi thêm ${formatTimeLeft(cooldownCheck.timeLeft)} nữa mới có thể tu luyện tiếp!`,
        };
    }

    setCooldown(userId, "training", getDefaultCooldown("training"));
    return { canProceed: true };
}

/**
 * Kiểm tra và đặt cooldown cho đột phá
 */
function handleBreakthroughCooldown(userId) {
    const cooldownCheck = checkCooldown(userId, "breakthrough");
    if (cooldownCheck.onCooldown) {
        return {
            canProceed: false,
            message: `⏰ Bạn cần ổn định tu vi thêm ${formatTimeLeft(cooldownCheck.timeLeft)} nữa mới có thể đột phá!`,
        };
    }

    setCooldown(userId, "breakthrough", getDefaultCooldown("breakthrough"));
    return { canProceed: true };
}

/**
 * Kiểm tra và đặt cooldown cho chiến đấu
 */
function handleCombatCooldown(userId) {
    const cooldownCheck = checkCooldown(userId, "combat");
    if (cooldownCheck.onCooldown) {
        return {
            canProceed: false,
            message: `⏰ Bạn cần hồi phục thêm ${formatTimeLeft(cooldownCheck.timeLeft)} nữa mới có thể chiến đấu!`,
        };
    }

    setCooldown(userId, "combat", getDefaultCooldown("combat"));
    return { canProceed: true };
}

/**
 * Lấy tất cả cooldown hiện tại của một user
 */
function getUserCooldowns(userId) {
    const actions = ["training", "breakthrough", "combat"];
    const userCooldowns = {};

    actions.forEach((action) => {
        const cooldownCheck = checkCooldown(userId, action);
        if (cooldownCheck.onCooldown) {
            userCooldowns[action] = {
                timeLeft: cooldownCheck.timeLeft,
                formatted: formatTimeLeft(cooldownCheck.timeLeft),
            };
        }
    });

    return userCooldowns;
}

/**
 * Xóa tất cả cooldown của một user (admin function)
 */
function clearUserCooldowns(userId) {
    const actions = ["training", "breakthrough", "combat"];
    actions.forEach((action) => {
        removeCooldown(userId, action);
    });
}

/**
 * Cleanup cooldowns đã hết hạn (chạy định kỳ)
 */
function cleanupExpiredCooldowns() {
    const now = Date.now();
    const toDelete = [];

    cooldowns.forEach((endTime, key) => {
        if (endTime <= now) {
            toDelete.push(key);
        }
    });

    toDelete.forEach((key) => cooldowns.delete(key));

    return toDelete.length;
}

// Cleanup tự động mỗi 10 phút
setInterval(cleanupExpiredCooldowns, 10 * 60 * 1000);

module.exports = {
    checkCooldown,
    setCooldown,
    removeCooldown,
    getDefaultCooldown,
    formatTimeLeft,
    handleTrainingCooldown,
    handleBreakthroughCooldown,
    handleCombatCooldown,
    getUserCooldowns,
    clearUserCooldowns,
    cleanupExpiredCooldowns,
};
