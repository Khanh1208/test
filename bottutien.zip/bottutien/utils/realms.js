// 27 cảnh giới tu vi từ thấp đến cao theo yêu cầu của user
const CULTIVATION_REALMS = [
    { id: 0, name: "Phàm Nhân", tier: 'Phàm', baseExp: 200, powerBase: 10 },
    { id: 1, name: "Luyện Thể", tier: 'Phàm', baseExp: 400, powerBase: 25 },
    { id: 2, name: "Khai Linh", tier: 'Phàm', baseExp: 800, powerBase: 50 },

    { id: 3, name: "Luyện Khí", tier: 'Luyện Khí', baseExp: 1000, powerBase: 100 },
    { id: 4, name: "Trúc Cơ", tier: 'Trúc Cơ', baseExp: 3000, powerBase: 300 },
    { id: 5, name: "Kim Đan", tier: 'Kim Đan', baseExp: 10000, powerBase: 1000 },
    { id: 6, name: "Nguyên Anh", tier: 'Nguyên Anh', baseExp: 30000, powerBase: 3000 },
    { id: 7, name: "Hóa Thần", tier: 'Hóa Thần', baseExp: 70000, powerBase: 7000 },
    { id: 8, name: "Luyện Hư", tier: 'Luyện Hư', baseExp: 150000, powerBase: 15000 },
    { id: 9, name: "Hợp Thể", tier: 'Hợp Thể', baseExp: 300000, powerBase: 30000 },
    { id: 10, name: "Đại Thừa", tier: 'Đại Thừa', baseExp: 600000, powerBase: 60000 },
    { id: 11, name: "Độ Kiếp", tier: 'Độ Kiếp', baseExp: 1000000, powerBase: 100000 },

    { id: 12, name: "Phi Thăng", tier: 'Phi Thăng', baseExp: 2000000, powerBase: 200000 },
    { id: 13, name: "Chân Tiên", tier: 'Chân Tiên', baseExp: 5000000, powerBase: 500000 },
    { id: 14, name: "Kim Tiên", tier: 'Kim Tiên', baseExp: 10000000, powerBase: 1000000 },
    { id: 15, name: "Thái Ất Chân Tiên", tier: 'Thái Ất', baseExp: 30000000, powerBase: 3000000 },
    { id: 16, name: "Đại La Kim Tiên", tier: 'Đại La', baseExp: 70000000, powerBase: 7000000 },

    { id: 17, name: "Tiên Vương", tier: 'Tiên Vương', baseExp: 100000000, powerBase: 10000000 },
    { id: 18, name: "Tiên Đế", tier: 'Tiên Đế', baseExp: 200000000, powerBase: 20000000 },
    { id: 19, name: "Bán Thánh", tier: 'Bán Thánh', baseExp: 400000000, powerBase: 40000000 },
    { id: 20, name: "Chân Thánh", tier: 'Chân Thánh', baseExp: 800000000, powerBase: 80000000 },
    { id: 21, name: "Thánh Vương", tier: 'Thánh Vương', baseExp: 1500000000, powerBase: 150000000 },
    { id: 22, name: "Thánh Đế", tier: 'Thánh Đế', baseExp: 3000000000, powerBase: 300000000 },

    { id: 23, name: "Đế Quân", tier: 'Đế Quân', baseExp: 5000000000, powerBase: 500000000 },
    { id: 24, name: "Tiên Tổ", tier: 'Tiên Tổ', baseExp: 8000000000, powerBase: 800000000 },
    { id: 25, name: "Hỗn Độn Cảnh", tier: 'Hỗn Độn', baseExp: 12000000000, powerBase: 1200000000 },
    { id: 26, name: "Sáng Thế Giả", tier: 'Sáng Thế', baseExp: 18000000000, powerBase: 1800000000 },
    { id: 27, name: "Thiên Đạo", tier: 'Thiên Đạo', baseExp: 30000000000, powerBase: 3000000000 }
];

// Emoji cho từng tier
const REALM_EMOJIS = {
    'Phàm': '🧑',
    'Luyện Khí': '⚡',
    'Trúc Cơ': '🏗️',
    'Kim Đan': '💊',
    'Nguyên Anh': '👤',
    'Hóa Thần': '🌟',
    'Luyện Hư': '🌀',
    'Hợp Thể': '🔮',
    'Đại Thừa': '⭐',
    'Độ Kiếp': '🌩️',
    'Phi Thăng': '🚀',
    'Chân Tiên': '✨',
    'Kim Tiên': '🏆',
    'Thái Ất': '💫',
    'Đại La': '🌌',
    'Tiên Vương': '👑',
    'Tiên Đế': '🔱',
    'Bán Thánh': '⚜️',
    'Chân Thánh': '🕊️',
    'Thánh Vương': '👸',
    'Thánh Đế': '🤴',
    'Đế Quân': '🗡️',
    'Tiên Tổ': '🧙‍♂️',
    'Hỗn Độn': '🌪️',
    'Sáng Thế': '🌍',
    'Thiên Đạo': '🌟'
};

// Màu sắc cho embed
const REALM_COLORS = {
    'Phàm': 0x8B4513,
    'Luyện Khí': 0x4169E1,
    'Trúc Cơ': 0x32CD32,
    'Kim Đan': 0xFFD700,
    'Nguyên Anh': 0xFF69B4,
    'Hóa Thần': 0x9370DB,
    'Luyện Hư': 0x00CED1,
    'Hợp Thể': 0xFF6347,
    'Đại Thừa': 0xFF4500,
    'Độ Kiếp': 0x8A2BE2,
    'Phi Thăng': 0x00FF7F,
    'Chân Tiên': 0x87CEEB,
    'Kim Tiên': 0xFFA500,
    'Thái Ất': 0xDA70D6,
    'Đại La': 0x191970,
    'Tiên Vương': 0xFFD700,
    'Tiên Đế': 0xFF1493,
    'Bán Thánh': 0x7FFFD4,
    'Chân Thánh': 0xF0F8FF,
    'Thánh Vương': 0xDDA0DD,
    'Thánh Đế': 0xFF69B4,
    'Đế Quân': 0xDC143C,
    'Tiên Tổ': 0x800080,
    'Hỗn Độn': 0x2F4F4F,
    'Sáng Thế': 0x00BFFF,
    'Thiên Đạo': 0xFFD700
};

/**
 * Lấy thông tin cảnh giới theo ID
 */
function getRealmById(realmId) {
    return CULTIVATION_REALMS[realmId] || CULTIVATION_REALMS[0];
}

/**
 * Lấy cảnh giới tiếp theo
 */
function getNextRealm(currentRealmId) {
    const nextId = currentRealmId + 1;
    return nextId < CULTIVATION_REALMS.length ? CULTIVATION_REALMS[nextId] : null;
}

/**
 * Kiểm tra có thể đột phá không
 */
function canBreakthrough(currentExp, currentRealmId) {
    const nextRealm = getNextRealm(currentRealmId);
    if (!nextRealm) return false;
    return currentExp >= nextRealm.baseExp;
}

// Tên các tiểu cảnh giới
const SUB_REALMS = [
    'Sơ Kỳ',    // Level 1
    'Trung Kỳ',  // Level 2  
    'Hậu Kỳ',    // Level 3
    'Viên Mãn'   // Level 4
];

/**
 * Lấy tên tiểu cảnh giới theo level
 */
function getSubRealmName(level) {
    return SUB_REALMS[level - 1] || 'Sơ Kỳ';
}

/**
 * Tính kinh nghiệm cần thiết cho level tiếp theo trong cùng cảnh giới
 */
function getExpToNextLevel(currentExp, realmId, currentLevel) {
    if (currentLevel >= 4) return 0; // Đã max level
    
    const realm = getRealmById(realmId);
    const expPerLevel = Math.floor(realm.baseExp / 4); // Chia đều 4 level
    const nextLevelExp = realm.baseExp - (realm.baseExp - (expPerLevel * currentLevel));
    
    return Math.max(0, nextLevelExp - currentExp);
}

/**
 * Tính level dựa trên kinh nghiệm hiện tại trong cảnh giới
 */
function calculateLevel(currentExp, realmId) {
    const realm = getRealmById(realmId);
    
    // Tính EXP tối thiểu để vào realm hiện tại
    let realmStartExp = 0;
    for (let i = 0; i < realmId; i++) {
        realmStartExp += CULTIVATION_REALMS[i].baseExp;
    }
    
    // EXP trong cảnh giới hiện tại = currentExp - EXP tối thiểu để vào realm này
    const expInCurrentRealm = Math.max(0, currentExp - realmStartExp);
    const expPerLevel = Math.floor(realm.baseExp / 4);
    
    // Nếu chưa có EXP thì level 1
    if (expInCurrentRealm <= 0) return 1;
    
    const level = Math.min(4, Math.floor(expInCurrentRealm / expPerLevel) + 1);
    return level;
}

/**
 * Tính sức mạnh chiến đấu
 */
function calculatePower(realmId, level = 1, bonusMultiplier = 1) {
    const realm = getRealmById(realmId);
    // Level từ 1-4 tăng 25% sức mạnh mỗi level
    const levelMultiplier = 1 + ((level - 1) * 0.25);
    return Math.floor(realm.powerBase * levelMultiplier * bonusMultiplier);
}

/**
 * Format hiển thị cảnh giới với tiểu cảnh giới
 */
function formatRealm(realm, level = 1) {
    const emoji = REALM_EMOJIS[realm.tier] || '❓';
    const subRealm = getSubRealmName(level);
    return `${emoji} ${realm.name} ${subRealm}`;
}

/**
 * Format hiển thị cảnh giới không có tiểu cảnh giới
 */
function formatRealmSimple(realm) {
    const emoji = REALM_EMOJIS[realm.tier] || '❓';
    return `${emoji} ${realm.name}`;
}

/**
 * Lấy màu cho embed theo tier
 */
function getRealmColor(tier) {
    return REALM_COLORS[tier] || 0x000000;
}

/**
 * Tính kinh nghiệm cần thiết cho cảnh giới tiếp theo
 */
function getExpToNext(currentExp, currentRealmId) {
    const nextRealm = getNextRealm(currentRealmId);
    if (!nextRealm) return 0;
    return Math.max(0, nextRealm.baseExp - currentExp);
}

module.exports = {
    CULTIVATION_REALMS,
    REALM_EMOJIS,
    REALM_COLORS,
    SUB_REALMS,
    getRealmById,
    getNextRealm,
    canBreakthrough,
    calculatePower,
    formatRealm,
    formatRealmSimple,
    getRealmColor,
    getExpToNext,
    getSubRealmName,
    getExpToNextLevel,
    calculateLevel
};
