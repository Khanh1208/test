const { EmbedBuilder } = require('discord.js');
const db = require('../utils/database');
const realms = require('../utils/realms');

module.exports = {
    name: 'bxh',
    aliases: ['leaderboard', 'ranking', 'top'],
    description: 'Xem bảng xếp hạng các tu sĩ',
    
    async execute(message, args, client) {
        const type = args[0]?.toLowerCase() || 'tuvi';
        
        switch (type) {
            case 'tuvi':
            case 'realm':
                return this.showRealmLeaderboard(message, client);
            case 'exp':
            case 'kinh nghiem':
                return this.showExpLeaderboard(message, client);
            case 'thang':
            case 'wins':
                return this.showWinsLeaderboard(message, client);
            case 'chiendat':
            case 'combat':
                return this.showCombatLeaderboard(message, client);
            default:
                return this.showHelp(message);
        }
    },
    
    async showRealmLeaderboard(message, client) {
        const topUsers = db.getTopUsers('realmId', 10);
        
        if (topUsers.length === 0) {
            return message.reply('❌ Chưa có tu sĩ nào trong bảng xếp hạng!');
        }
        
        const embed = new EmbedBuilder()
            .setColor(0xFFD700)
            .setTitle('🏆 Bảng Xếp Hạng Tu Vi')
            .setDescription('Top 10 tu sĩ có tu vi cao nhất')
            .setTimestamp();
        
        let description = '';
        for (let i = 0; i < topUsers.length; i++) {
            const user = topUsers[i];
            const discordUser = await client.users.fetch(user.userId).catch(() => null);
            const username = discordUser ? discordUser.username : 'Unknown User';
            const realm = realms.getRealmById(user.realmId);
            const medal = this.getMedal(i);
            
            description += `${medal} **${username}**\n`;
            description += `   ${realms.formatRealm(realm)} - ${user.experience.toLocaleString()} EXP\n\n`;
        }
        
        embed.setDescription(description);
        
        // Thêm thông tin của người dùng hiện tại
        const currentUser = db.getUser(message.author.id);
        const allUsers = db.getTopUsers('realmId', 1000);
        const userRank = allUsers.findIndex(u => u.userId === message.author.id) + 1;
        
        if (userRank > 0) {
            const currentRealm = realms.getRealmById(currentUser.realmId);
            embed.addFields({
                name: '📊 Hạng Của Bạn',
                value: `Hạng ${userRank} - ${realms.formatRealm(currentRealm)}\n${currentUser.experience.toLocaleString()} EXP`,
                inline: false
            });
        }
        
        embed.setFooter({ text: 'Sử dụng !bxh exp để xem bảng xếp hạng kinh nghiệm' });
        
        message.reply({ embeds: [embed] });
    },
    
    async showExpLeaderboard(message, client) {
        const topUsers = db.getTopUsers('experience', 10);
        
        const embed = new EmbedBuilder()
            .setColor(0x9370DB)
            .setTitle('📈 Bảng Xếp Hạng Kinh Nghiệm')
            .setDescription('Top 10 tu sĩ có kinh nghiệm cao nhất')
            .setTimestamp();
        
        let description = '';
        for (let i = 0; i < topUsers.length; i++) {
            const user = topUsers[i];
            const discordUser = await client.users.fetch(user.userId).catch(() => null);
            const username = discordUser ? discordUser.username : 'Unknown User';
            const realm = realms.getRealmById(user.realmId);
            const medal = this.getMedal(i);
            
            description += `${medal} **${username}**\n`;
            description += `   ${user.experience.toLocaleString()} EXP - ${realms.formatRealm(realm)}\n\n`;
        }
        
        embed.setDescription(description);
        embed.setFooter({ text: 'Sử dụng !bxh thang để xem bảng xếp hạng chiến thắng' });
        
        message.reply({ embeds: [embed] });
    },
    
    async showWinsLeaderboard(message, client) {
        const topUsers = db.getTopUsers('wins', 10);
        
        const embed = new EmbedBuilder()
            .setColor(0xFF6347)
            .setTitle('⚔️ Bảng Xếp Hạng Chiến Thắng')
            .setDescription('Top 10 tu sĩ có nhiều chiến thắng nhất')
            .setTimestamp();
        
        let description = '';
        for (let i = 0; i < topUsers.length; i++) {
            const user = topUsers[i];
            const discordUser = await client.users.fetch(user.userId).catch(() => null);
            const username = discordUser ? discordUser.username : 'Unknown User';
            const realm = realms.getRealmById(user.realmId);
            const medal = this.getMedal(i);
            const winRate = user.stats.totalCombats > 0 ? 
                ((user.stats.winsCount / user.stats.totalCombats) * 100).toFixed(1) : 0;
            
            description += `${medal} **${username}**\n`;
            description += `   ${user.stats.winsCount} thắng (${winRate}%) - ${realms.formatRealm(realm)}\n\n`;
        }
        
        embed.setDescription(description);
        embed.setFooter({ text: 'Sử dụng !bxh chiendat để xem thống kê chiến đấu' });
        
        message.reply({ embeds: [embed] });
    },
    
    async showCombatLeaderboard(message, client) {
        const topUsers = db.getAllUsers()
            .filter(u => u.stats.totalCombats > 0)
            .sort((a, b) => {
                const aRate = a.stats.winsCount / a.stats.totalCombats;
                const bRate = b.stats.winsCount / b.stats.totalCombats;
                return bRate - aRate;
            })
            .slice(0, 10);
        
        if (topUsers.length === 0) {
            return message.reply('❌ Chưa có ai tham gia chiến đấu!');
        }
        
        const embed = new EmbedBuilder()
            .setColor(0x32CD32)
            .setTitle('🎯 Bảng Xếp Hạng Tỷ Lệ Thắng')
            .setDescription('Top 10 tu sĩ có tỷ lệ thắng cao nhất (tối thiểu 5 trận)')
            .setTimestamp();
        
        let description = '';
        for (let i = 0; i < topUsers.length; i++) {
            const user = topUsers[i];
            
            // Chỉ hiển thị những người có ít nhất 5 trận
            if (user.stats.totalCombats < 5) continue;
            
            const discordUser = await client.users.fetch(user.userId).catch(() => null);
            const username = discordUser ? discordUser.username : 'Unknown User';
            const realm = realms.getRealmById(user.realmId);
            const medal = this.getMedal(i);
            const winRate = ((user.stats.winsCount / user.stats.totalCombats) * 100).toFixed(1);
            
            description += `${medal} **${username}**\n`;
            description += `   ${winRate}% (${user.stats.winsCount}/${user.stats.totalCombats}) - ${realms.formatRealm(realm)}\n\n`;
        }
        
        if (!description) {
            return message.reply('❌ Chưa có ai đủ 5 trận chiến đấu để xếp hạng!');
        }
        
        embed.setDescription(description);
        embed.setFooter({ text: 'Cần tối thiểu 5 trận để được xếp hạng' });
        
        message.reply({ embeds: [embed] });
    },
    
    showHelp(message) {
        const embed = new EmbedBuilder()
            .setColor(0x00CED1)
            .setTitle('📋 Hướng Dẫn Bảng Xếp Hạng')
            .setDescription('Các loại bảng xếp hạng có sẵn:')
            .addFields(
                { name: '!bxh tuvi', value: 'Xếp hạng theo tu vi', inline: true },
                { name: '!bxh exp', value: 'Xếp hạng theo kinh nghiệm', inline: true },
                { name: '!bxh thang', value: 'Xếp hạng theo số trận thắng', inline: true },
                { name: '!bxh chiendat', value: 'Xếp hạng theo tỷ lệ thắng', inline: true }
            )
            .setFooter({ text: 'Mặc định sẽ hiển thị bảng xếp hạng tu vi' });
        
        message.reply({ embeds: [embed] });
    },
    
    getMedal(rank) {
        switch (rank) {
            case 0: return '🥇';
            case 1: return '🥈';
            case 2: return '🥉';
            default: return `**${rank + 1}.**`;
        }
    }
};
