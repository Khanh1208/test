const { EmbedBuilder } = require("discord.js");
const db = require("../utils/database");
const realms = require("../utils/realms");
const cooldowns = require("../utils/cooldowns");

module.exports = {
    name: "trangthai",
    aliases: ["tt", "hoso", "profile"],
    description: "Xem trạng thái tu vi và thông tin cá nhân",

    async execute(message, args, client) {
        // Kiểm tra có tag user khác không
        const targetUser = message.mentions.users.first() || message.author;
        const userId = targetUser.id;

        // Kiểm tra user có tồn tại trong database không
        if (!db.userExists(userId)) {
            if (targetUser.id === message.author.id) {
                return message.reply(
                    "❌ Bạn chưa đăng ký tham gia tu tiên!\nSử dụng `!dk` để đăng ký trước.",
                );
            } else {
                return message.reply(
                    "❌ Người dùng này chưa đăng ký tham gia tu tiên!",
                );
            }
        }

        const user = db.getUser(userId);
        const currentRealm = realms.getRealmById(user.realmId);
        const nextRealm = realms.getNextRealm(user.realmId);
        const power = realms.calculatePower(user.realmId);
        const attributes = db.calculateTotalAttributes(userId);

        // Tính toán thống kê
        const winRate =
            user.stats.totalCombats > 0
                ? (
                      (user.stats.winsCount / user.stats.totalCombats) *
                      100
                  ).toFixed(1)
                : 0;

        const expToNext = nextRealm
            ? realms.getExpToNext(user.experience, user.realmId)
            : 0;
        const progressPercent = nextRealm
            ? (
                  ((user.experience - currentRealm.baseExp) /
                      (nextRealm.baseExp - currentRealm.baseExp)) *
                  100
              ).toFixed(1)
            : 100;

        // Lấy thông tin cooldowns
        const userCooldowns = cooldowns.getUserCooldowns(userId);

        // Tạo embed với style mới giống hình
        const embed = new EmbedBuilder()
            .setColor(realms.getRealmColor(currentRealm.tier))
            .setAuthor({
                name: `Thông Tin - ${targetUser.username}`,
                iconURL: targetUser.displayAvatarURL({ dynamic: true }),
            })
            .setThumbnail(targetUser.displayAvatarURL({ dynamic: true }))
            .addFields(
                {
                    name: "🌟 Thông tin cơ bản",
                    value: `────────────────────────`,
                    inline: false,
                },
                {
                    name: "⚔️ Thuộc Tính",
                    value: `🔥 ${attributes.atk}   🔮 ${attributes.mana}\n❤️ ${attributes.hp}   🛡️ ${attributes.defense}`,
                    inline: true,
                },
                {
                    name: "👤 Danh Tính",
                    value: `⚡ ${targetUser.username}\n🌟 Tu Sĩ`,
                    inline: true,
                },
                {
                    name: "💰 Gia Tài",
                    value: `💎 ${user.resources.linhThach.toLocaleString()} Vàng`,
                    inline: true,
                },
                {
                    name: "🏆 Cảnh Giới",
                    value: `${realms.formatRealm(currentRealm)}`,
                    inline: true,
                },
                {
                    name: "🎒 Tài Nguyên",
                    value: `⚡ Linh Khí: ${user.resources.linhKhi.toLocaleString()}\n💊 Đan Dược: ${user.resources.danDuoc.toLocaleString()}`,
                    inline: true,
                },
                {
                    name: "📊 Thống Kê",
                    value: `⚔️ Chiến: ${user.stats.totalCombats}\n🏆 Thắng: ${user.stats.winsCount} (${winRate}%)`,
                    inline: true,
                },
                {
                    name: "🎯 Hoạt Động",
                    value: `🧘 Tu luyện: ${user.stats.totalTraining}\n💫 Đột phá: ${user.stats.totalBreakthroughs}`,
                    inline: true,
                },
                {
                    name: "💪 Sức Mạnh Chiến Đấu",
                    value: `${Math.floor((attributes.atk * 2 + attributes.hp + attributes.defense + attributes.mana) / 5).toLocaleString()}`,
                    inline: true,
                },
            )
            .setFooter({
                text: `Ngày nối vui với: ${new Date(user.timestamps.joined).toLocaleDateString("vi-VN")} ${new Date(user.timestamps.joined).toLocaleTimeString("vi-VN", { hour: "2-digit", minute: "2-digit" })} CH`,
            })
            .setTimestamp();

        // Thêm thông tin tiến độ nếu chưa max realm
        if (nextRealm) {
            embed.addFields({
                name: "🚀 Tiến Độ Đột Phá",
                value: `**Cảnh giới tiếp theo:** ${realms.formatRealm(nextRealm)}\n**EXP cần thêm:** ${expToNext.toLocaleString()}\n**Tiến độ:** ${progressPercent}%`,
                inline: false,
            });
        } else {
            embed.addFields({
                name: "👑 Đã Đạt Đỉnh Cao",
                value: "Bạn đã đạt được cảnh giới cao nhất - Thiên Đạo!",
                inline: false,
            });
        }

        // Thêm thông tin cooldowns nếu có
        if (Object.keys(userCooldowns).length > 0) {
            const cooldownText = Object.entries(userCooldowns)
                .map(([action, data]) => {
                    const actionNames = {
                        training: "Tu luyện",
                        breakthrough: "Đột phá",
                        combat: "Chiến đấu",
                    };
                    return `${actionNames[action]}: ${data.formatted}`;
                })
                .join("\n");

            embed.addFields({
                name: "⏰ Thời Gian Hồi Chiêu",
                value: cooldownText,
                inline: false,
            });
        }

        // Thêm footer với ngày tham gia
        const joinDate = new Date(user.timestamps.joined).toLocaleDateString(
            "vi-VN",
        );
        embed.setFooter({ text: `Bắt đầu tu luyện từ: ${joinDate}` });

        message.reply({ embeds: [embed] });
    },
};
