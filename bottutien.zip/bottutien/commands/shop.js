const { EmbedBuilder } = require("discord.js");
const db = require("../utils/database");
const {
    getAllItems,
    getItemById,
    formatItem,
    createItemEmbed,
    getItemsByType,
    ITEM_TYPES,
} = require("../utils/items");

/**
 * Lệnh xem shop !shop [loại]
 */
function handleShopCommand(message, args) {
    const userId = message.author.id;

    // Kiểm tra đã đăng ký chưa
    if (!db.userExists(userId)) {
        return message.reply(
            "❌ Bạn chưa đăng ký! Sử dụng lệnh `!dk` để đăng ký.",
        );
    }

    const user = db.getUser(userId);
    const typeFilter = args[0]?.toLowerCase();

    let items = [];
    let shopTitle = "🏪 Cửa Hàng Tu Tiên";

    // Lọc theo loại nếu có
    switch (typeFilter) {
        case "weapon":
        case "vu-khi":
            items = getItemsByType(ITEM_TYPES.WEAPON);
            shopTitle = "⚔️ Cửa Hàng Vũ Khí";
            break;
        case "armor":
        case "ao-giap":
            items = getItemsByType(ITEM_TYPES.ARMOR);
            shopTitle = "🛡️ Cửa Hàng Áo Giáp";
            break;
        case "pill":
        case "dan-duoc":
            return message.reply(
                "💊 **Đan dược không còn bán trong shop!**\n\\n💰 Liên hệ admin để biết thêm chi tiết về cách mua đan dược premium.",
            );
        case "material":
        case "nguyen-lieu":
            items = getItemsByType(ITEM_TYPES.MATERIAL);
            shopTitle = "🌿 Cửa Hàng Nguyên Liệu";
            break;
        case "treasure":
        case "bao-vat":
            items = getItemsByType(ITEM_TYPES.TREASURE);
            shopTitle = "💎 Cửa Hàng Bảo Vật";
            break;
        default:
            // Lấy tất cả items trừ đan dược
            items = getAllItems().filter(
                (item) => item.type !== ITEM_TYPES.PILL,
            );
            break;
    }

    // Sắp xếp theo giá
    items.sort((a, b) => a.price - b.price);

    const embed = new EmbedBuilder()
        .setColor(0xffd700)
        .setTitle(shopTitle)
        .setDescription(
            `💰 **Linh Thạch của bạn:** ${user.resources.linhThach.toLocaleString()}`,
        );

    // Hiển thị danh sách vật phẩm
    let itemList = "";
    items.forEach((item) => {
        const canAfford = user.resources.linhThach >= item.price ? "✅" : "❌";
        itemList += `${canAfford} **ID: ${item.id}** - ${formatItem(item)} - ${item.price.toLocaleString()} 💎\n`;
    });

    if (itemList.length > 1024) {
        // Nếu quá dài, chia thành nhiều field
        const chunks = itemList.match(/[\s\S]{1,1024}/g) || [];
        chunks.forEach((chunk, index) => {
            embed.addFields({
                name: index === 0 ? "🛍️ Danh Sách Vật Phẩm" : "⠀",
                value: chunk,
                inline: false,
            });
        });
    } else {
        embed.addFields({
            name: "🛍️ Danh Sách Vật Phẩm",
            value: itemList || "Không có vật phẩm nào",
            inline: false,
        });
    }

    // Hướng dẫn
    embed.addFields({
        name: "📖 Hướng Dẫn Mua Hàng",
        value: "• `!buy <id> [số lượng]` - Mua vật phẩm\n• `!item <id>` - Xem chi tiết vật phẩm\n• `!shop <loại>` - Lọc theo loại (weapon/armor/material/treasure)\n• Đan dược không còn bán trong !shop - liên hệ admin để biết thêm chi tiết",
        inline: false,
    });

    embed.setFooter({ text: `Tổng cộng: ${items.length} vật phẩm` });

    return message.reply({ embeds: [embed] });
}

/**
 * Lệnh mua đồ !buy <id> [số lượng]
 */
function handleBuyCommand(message, args) {
    const userId = message.author.id;

    if (!db.userExists(userId)) {
        return message.reply(
            "❌ Bạn chưa đăng ký! Sử dụng lệnh `!dk` để đăng ký.",
        );
    }

    const itemId = parseInt(args[0]);
    const quantity = parseInt(args[1]) || 1;

    if (!itemId) {
        return message.reply("❌ Vui lòng nhập ID vật phẩm! Ví dụ: `!buy 1`");
    }

    if (quantity < 1 || quantity > 99) {
        return message.reply("❌ Số lượng phải từ 1 đến 99!");
    }

    const item = getItemById(itemId);
    if (!item) {
        return message.reply("❌ Không tìm thấy vật phẩm với ID này!");
    }

    const user = db.getUser(userId);
    const totalPrice = item.price * quantity;

    // Kiểm tra đủ tiền
    if (user.resources.linhThach < totalPrice) {
        return message.reply(
            `❌ Không đủ Linh Thạch! Cần ${totalPrice.toLocaleString()} 💎 (Hiện có: ${user.resources.linhThach.toLocaleString()} 💎)`,
        );
    }

    // Thực hiện mua
    const success = db.spendResources(userId, { linhThach: totalPrice });
    if (success) {
        db.addItemToInventory(userId, itemId, quantity);

        const quantityText = quantity > 1 ? ` x${quantity}` : "";
        return message.reply(
            `✅ Đã mua ${formatItem(item)}${quantityText} với giá ${totalPrice.toLocaleString()} 💎\n💰 Linh Thạch còn lại: ${(user.resources.linhThach - totalPrice).toLocaleString()} 💎`,
        );
    } else {
        return message.reply("❌ Có lỗi xảy ra khi mua vật phẩm!");
    }
}

/**
 * Lệnh bán đồ !sell <id> [số lượng]
 */
function handleSellCommand(message, args) {
    const userId = message.author.id;

    if (!db.userExists(userId)) {
        return message.reply(
            "❌ Bạn chưa đăng ký! Sử dụng lệnh `!dk` để đăng ký.",
        );
    }

    const itemId = parseInt(args[0]);
    const quantity = parseInt(args[1]) || 1;

    if (!itemId) {
        return message.reply("❌ Vui lòng nhập ID vật phẩm! Ví dụ: `!sell 1`");
    }

    if (quantity < 1) {
        return message.reply("❌ Số lượng phải lớn hơn 0!");
    }

    const item = getItemById(itemId);
    if (!item) {
        return message.reply("❌ Không tìm thấy vật phẩm với ID này!");
    }

    if (!db.hasItemInInventory(userId, itemId, quantity)) {
        return message.reply("❌ Bạn không có đủ vật phẩm này trong kho!");
    }

    // Giá bán = 50% giá mua
    const sellPrice = Math.floor(item.price * 0.5);
    const totalPrice = sellPrice * quantity;

    // Thực hiện bán
    const removed = db.removeItemFromInventory(userId, itemId, quantity);
    if (removed) {
        db.addResources(userId, { linhThach: totalPrice });

        const quantityText = quantity > 1 ? ` x${quantity}` : "";
        return message.reply(
            `✅ Đã bán ${formatItem(item)}${quantityText} với giá ${totalPrice.toLocaleString()} 💎\n💰 Linh Thạch hiện tại: ${db.getUser(userId).resources.linhThach.toLocaleString()} 💎`,
        );
    } else {
        return message.reply("❌ Có lỗi xảy ra khi bán vật phẩm!");
    }
}

module.exports = {
    handleShopCommand,
    handleBuyCommand,
    handleSellCommand,
};
