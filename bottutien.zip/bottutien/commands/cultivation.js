const { EmbedBuilder } = require('discord.js');
const db = require('../utils/database');
const realms = require('../utils/realms');
const cooldowns = require('../utils/cooldowns');
const config = require('../config');

module.exports = {
    name: 'tuluyen',
    description: 'Tu luyện để tăng kinh nghiệm và tu vi',
    
    async execute(message, args, client) {
        const userId = message.author.id;
        
        // Kiểm tra đã đăng ký chưa
        if (!db.userExists(userId)) {
            return message.reply('❌ Bạn chưa đăng ký tham gia tu tiên!\nSử dụng `!dk` để đăng ký trước khi tu luyện.');
        }
        
        const user = db.getUser(userId);
        
        // Kiểm tra giới hạn tu luyện hàng ngày
        if (user.dailyLimits.trainingCount >= config.CULTIVATION.MAX_TRAINING_PER_DAY) {
            const tomorrow = new Date();
            tomorrow.setDate(tomorrow.getDate() + 1);
            tomorrow.setHours(0, 0, 0, 0);
            const timeUntilReset = tomorrow.getTime() - Date.now();
            const hoursLeft = Math.ceil(timeUntilReset / (1000 * 60 * 60));
            
            return message.reply(`⏰ Bạn đã tu luyện đủ 5 lần hôm nay (5 giờ)!\nGiới hạn sẽ reset sau ${hoursLeft} giờ nữa.\nHãy nghỉ ngơi để chuẩn bị cho ngày mai!`);
        }
        
        // Kiểm tra cooldown
        const cooldownResult = cooldowns.handleTrainingCooldown(userId);
        if (!cooldownResult.canProceed) {
            return message.reply(cooldownResult.message);
        }
        
        const currentRealm = realms.getRealmById(user.realmId);
        
        // Tính toán kinh nghiệm theo thời gian (1 EXP/giây trong 30 phút = 1800 EXP)
        const baseExpPerSecond = 1;
        const trainingDurationSeconds = 30 * 60; // 30 phút
        let baseExp = baseExpPerSecond * trainingDurationSeconds; // 1800 EXP cơ bản
        
        // Bonus theo cảnh giới hiện tại
        const realmBonus = Math.floor(baseExp * (user.realmId * 0.1));
        
        // Random bonus
        const randomMultiplier = Math.random() * 
            (config.CULTIVATION.RANDOM_EXP_BONUS.MAX - config.CULTIVATION.RANDOM_EXP_BONUS.MIN) + 
            config.CULTIVATION.RANDOM_EXP_BONUS.MIN;
        
        const totalExp = Math.floor((baseExp + realmBonus) * randomMultiplier);
        
        // Thêm kinh nghiệm và cập nhật daily count
        user.experience += totalExp;
        user.stats.totalTraining++;
        user.dailyLimits.trainingCount++;
        
        // Tự động cập nhật level dựa trên kinh nghiệm hiện tại
        user.level = realms.calculateLevel(user.experience, user.realmId);
        
        // Random tài nguyên
        const linhKhiGain = Math.floor(Math.random() * 50) + 20;
        const linhThachGain = Math.floor(Math.random() * 20) + 5;
        
        db.addResources(userId, {
            linhKhi: linhKhiGain,
            linhThach: linhThachGain
        });
        
        // Random events
        const events = [
            '🌟 Bạn cảm nhận được linh khí trong không khí đặc biệt tinh khiết!',
            '⚡ Trong lúc tu luyện, bạn có chút lĩnh ngộ về Đạo!',
            '💫 Kinh mạch của bạn dần mở rộng và kiên cố hơn!',
            '🔮 Bạn cảm thấy tu vi của mình tiến bộ vượt bậc!',
            '🌸 Hôm nay là ngày may mắn, tu luyện hiệu quả gấp đôi!',
            '⭐ Thiên đạo dường như đang phù trợ cho bạn!',
            '🍃 Bạn tu luyện trong thanh tịnh, tâm trí trong veo như nước!',
            '🏔️ Như có thiên thu học tuyết, tu vi bạn tiến bộ thần tốc!'
        ];
        
        const randomEvent = Math.random() < 0.3 ? events[Math.floor(Math.random() * events.length)] : null;
        
        // Lưu dữ liệu
        db.saveUser(user);
        
        // Tính progress bar cho cảnh giới hiện tại
        const nextRealm = realms.getNextRealm(user.realmId);
        let progressBar = '';
        let progressText = '';
        
        if (nextRealm) {
            // Tính EXP tối thiểu để vào realm hiện tại
            let realmStartExp = 0;
            for (let i = 0; i < user.realmId; i++) {
                realmStartExp += realms.CULTIVATION_REALMS[i].baseExp;
            }
            
            const totalExpNeeded = currentRealm.baseExp;
            const currentProgress = Math.max(0, user.experience - realmStartExp);
            const progressPercent = Math.max(0, Math.min(100, Math.floor((currentProgress / totalExpNeeded) * 100)));
            
            // Tạo progress bar với ▓ và ░
            const filledBars = Math.max(0, Math.min(20, Math.floor((progressPercent / 100) * 20)));
            const emptyBars = Math.max(0, 20 - filledBars);
            progressBar = '▓'.repeat(filledBars) + '░'.repeat(emptyBars);
            const totalExpToComplete = realmStartExp + currentRealm.baseExp;
            progressText = `${user.experience.toLocaleString()}/${totalExpToComplete.toLocaleString()} (${progressPercent}%)`;
        } else {
            progressBar = '▓'.repeat(20);
            progressText = 'MAX LEVEL';
        }

        // Tạo embed phản hồi với style mới
        const embed = new EmbedBuilder()
            .setColor(realms.getRealmColor(currentRealm.tier))
            .setAuthor({ 
                name: `Tu Luyện - ${message.author.username}`,
                iconURL: message.author.displayAvatarURL({ dynamic: true })
            })
            .addFields(
                {
                    name: '🏆 Cảnh Giới',
                    value: `${realms.formatRealm(currentRealm, user.level)}`,
                    inline: true
                },
                {
                    name: '🌟 Tu Vi',
                    value: `${user.experience.toLocaleString()}/${nextRealm ? nextRealm.baseExp.toLocaleString() : 'MAX'}`,
                    inline: true
                },
                {
                    name: '✅ Tiến Trình',
                    value: progressBar,
                    inline: false
                },
                {
                    name: '📊 Chỉ Số',
                    value: `💫 EXP: +${totalExp.toLocaleString()}\n⚡ Linh Khí: +${linhKhiGain}\n⏱️ Tu luyện hôm nay: ${user.dailyLimits.trainingCount}/${config.CULTIVATION.MAX_TRAINING_PER_DAY}`,
                    inline: true
                },
                {
                    name: '🎁 Tổng Môn',
                    value: nextRealm ? 'Chưa gia nhập' : 'Thiên Đạo Tông',
                    inline: true
                }
            )
            .setTimestamp()
        
        // Thêm random event nếu có
        if (randomEvent) {
            embed.addFields({ name: '🎲 Sự Kiện Đặc Biệt', value: randomEvent, inline: false });
        }
        
        // Kiểm tra có thể đột phá không
        if (realms.canBreakthrough(user.experience, user.realmId)) {
            embed.addFields({
                name: '🚀 Có Thể Đột Phá!',
                value: `Bạn đã đủ kinh nghiệm để đột phá lên **${realms.formatRealm(realms.getNextRealm(user.realmId))}**!\nSử dụng \`!dotpha\` để thử đột phá!`,
                inline: false
            });
        }
        
        message.reply({ embeds: [embed] });
    }
};
