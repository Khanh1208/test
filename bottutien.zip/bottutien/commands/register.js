const { EmbedBuilder } = require('discord.js');
const db = require('../utils/database');
const realms = require('../utils/realms');

module.exports = {
    name: 'dk',
    aliases: ['dangky', 'register', 'join'],
    description: 'Đăng ký tham gia tu tiên',
    
    async execute(message, args, client) {
        const userId = message.author.id;
        
        // Kiểm tra đã đăng ký chưa
        if (db.userExists(userId)) {
            const user = db.getUser(userId);
            const currentRealm = realms.getRealmById(user.realmId);
            
            const embed = new EmbedBuilder()
                .setColor(0xFF6B6B)
                .setTitle('⚠️ Đã Tham Gia Tu Tiên')
                .setDescription(`**${message.author.username}** đã là tu sĩ rồi!`)
                .addFields(
                    {
                        name: '🏆 Tu Vi Hiện Tại',
                        value: realms.formatRealm(currentRealm),
                        inline: true
                    },
                    {
                        name: '📊 Kinh Nghiệm',
                        value: `${user.experience.toLocaleString()} EXP`,
                        inline: true
                    }
                )
                .setFooter({ text: 'Sử dụng !hotro để xem các lệnh có thể dùng!' })
                .setTimestamp();
                
            return message.reply({ embeds: [embed] });
        }
        
        // Đăng ký mới
        const newUser = db.getUser(userId); // Tự động tạo user mới
        const startRealm = realms.getRealmById(0);
        
        const embed = new EmbedBuilder()
            .setColor(0x4ECDC4)
            .setTitle('🎉 Chào Mừng Tu Sĩ Mới!')
            .setDescription(`**${message.author.username}** đã bước vào con đường tu tiên!`)
            .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
            .addFields(
                {
                    name: '🌟 Tu Vi Bắt Đầu',
                    value: realms.formatRealm(startRealm),
                    inline: true
                },
                {
                    name: '💎 Tài Nguyên Ban Đầu',
                    value: `⚡ ${newUser.resources.linhKhi.toLocaleString()} Linh Khí\n💰 ${newUser.resources.linhThach.toLocaleString()} Linh Thạch\n💊 ${newUser.resources.danDuoc} Đan Dược`,
                    inline: true
                },
                {
                    name: '📚 Hướng Dẫn Cơ Bản',
                    value: '• `!tuluyen` - Tu luyện để tăng kinh nghiệm (30 phút)\n• `!dotpha` - Đột phá lên cảnh giới cao hơn\n• `!chiendat` - Thách đấu với người khác\n• `!trangthai` - Xem thông tin cá nhân\n• `!hotro` - Xem tất cả lệnh',
                    inline: false
                },
                {
                    name: '🎯 Mục Tiêu',
                    value: 'Hãy tu luyện chăm chỉ để từ **Phàm Nhân** tiến đến **Thiên Đạo**!\nChúc bạn may mắn trên con đường tu tiên!',
                    inline: false
                }
            )
            .setFooter({ text: 'Bắt đầu hành trình tu tiên của bạn ngay bây giờ!' })
            .setTimestamp();
            
        message.reply({ embeds: [embed] });
    }
};