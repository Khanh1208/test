const { EmbedBuilder } = require('discord.js');
const db = require('../utils/database');
const realms = require('../utils/realms');
const cooldowns = require('../utils/cooldowns');
const config = require('../config');

module.exports = {
    name: 'chiendau',
    aliases: ['chiendat', 'combat', 'fight', 'duel'],
    description: 'Thách đấu với tu sĩ khác',
    
    async execute(message, args, client) {
        const challengerId = message.author.id;
        
        // Kiểm tra đã đăng ký chưa
        if (!db.userExists(challengerId)) {
            return message.reply('❌ Bạn chưa đăng ký tham gia tu tiên!\nSử dụng `!dk` để đăng ký trước khi chiến đấu.');
        }
        
        // Kiểm tra cooldown
        const cooldownResult = cooldowns.handleCombatCooldown(challengerId);
        if (!cooldownResult.canProceed) {
            return message.reply(cooldownResult.message);
        }
        
        // Kiểm tra có tag đối thủ không
        const targetUser = message.mentions.users.first();
        if (!targetUser) {
            // Nếu không tag ai, tìm đối thủ ngẫu nhiên
            return this.findRandomOpponent(message, challengerId);
        }
        
        if (targetUser.bot) {
            return message.reply('❌ Không thể thách đấu với bot!');
        }
        
        if (targetUser.id === challengerId) {
            return message.reply('❌ Không thể tự thách đấu với chính mình!');
        }
        
        // Kiểm tra đối thủ có tồn tại trong database không
        if (!db.userExists(targetUser.id)) {
            return message.reply('❌ Đối thủ này chưa bắt đầu tu luyện!');
        }
        
        return this.startCombat(message, challengerId, targetUser.id);
    },
    
    async findRandomOpponent(message, challengerId) {
        const challenger = db.getUser(challengerId);
        const allUsers = db.getAllUsers().filter(u => 
            u.userId !== challengerId && 
            Math.abs(u.realmId - challenger.realmId) <= 2 // Tìm đối thủ cùng trình độ
        );
        
        if (allUsers.length === 0) {
            return message.reply('❌ Không tìm thấy đối thủ phù hợp! Hãy tag một tu sĩ cụ thể để thách đấu.');
        }
        
        const randomOpponent = allUsers[Math.floor(Math.random() * allUsers.length)];
        return this.startCombat(message, challengerId, randomOpponent.userId);
    },
    
    async startCombat(message, challengerId, opponentId) {
        const challenger = db.getUser(challengerId);
        const opponent = db.getUser(opponentId);
        
        const challengerRealm = realms.getRealmById(challenger.realmId);
        const opponentRealm = realms.getRealmById(opponent.realmId);
        
        // Tính sức mạnh chiến đấu
        const challengerPower = this.calculateCombatPower(challenger);
        const opponentPower = this.calculateCombatPower(opponent);
        
        // Mô phỏng chiến đấu
        const battleResult = this.simulateBattle(challenger, opponent, challengerPower, opponentPower);
        
        // Cập nhật kết quả
        const winnerData = battleResult.winner === 'challenger' ? challenger : opponent;
        const loserData = battleResult.winner === 'challenger' ? opponent : challenger;
        
        // Cập nhật thống kê
        db.updateCombatStats(winnerData.userId, true);
        db.updateCombatStats(loserData.userId, false);
        
        // Tính toán phần thưởng và hình phạt
        const rewards = this.calculateRewards(battleResult, winnerData.realmId, loserData.realmId);
        
        // Áp dụng phần thưởng
        db.addExperience(winnerData.userId, rewards.winnerExp);
        db.addExperience(loserData.userId, rewards.loserExp);
        db.addResources(winnerData.userId, rewards.winnerResources);
        
        // Tạo embed kết quả
        const embed = this.createBattleResultEmbed(
            message, challenger, opponent, battleResult, rewards
        );
        
        message.reply({ embeds: [embed] });
    },
    
    calculateCombatPower(user) {
        const basePower = realms.calculatePower(user.realmId, user.level);
        
        // Bonus từ tài nguyên
        const resourceBonus = Math.floor(user.resources.linhKhi * 0.1);
        
        // Bonus từ streak thắng
        const streakBonus = Math.floor(basePower * (user.stats.consecutiveWins * 0.05));
        
        // Random factor (±20%)
        const randomFactor = 0.8 + (Math.random() * 0.4);
        
        return Math.floor((basePower + resourceBonus + streakBonus) * randomFactor);
    },
    
    simulateBattle(challenger, opponent, challengerPower, opponentPower) {
        const totalPower = challengerPower + opponentPower;
        const challengerWinChance = challengerPower / totalPower;
        
        // Thêm yếu tố may mắn
        const randomFactor = Math.random();
        const winner = randomFactor < challengerWinChance ? 'challenger' : 'opponent';
        
        // Tạo mô tả chiến đấu
        const battleDescription = this.generateBattleDescription(
            challenger, opponent, challengerPower, opponentPower, winner
        );
        
        return {
            winner,
            challengerPower,
            opponentPower,
            battleDescription,
            powerDifference: Math.abs(challengerPower - opponentPower)
        };
    },
    
    generateBattleDescription(challenger, opponent, challengerPower, opponentPower, winner) {
        const challengerRealm = realms.getRealmById(challenger.realmId);
        const opponentRealm = realms.getRealmById(opponent.realmId);
        
        const descriptions = [
            `⚔️ Cuộc chiến giữa ${realms.formatRealm(challengerRealm)} và ${realms.formatRealm(opponentRealm)} diễn ra khốc liệt!`,
            `💥 Linh khí bùng nổ, hai tu sĩ đối đầu trong một trận đấu sinh tử!`,
            `🌟 Thiên địa chấn động trước sức mạnh của hai cao thủ!`,
            `⚡ Pháp thuật và võ học va chạm, tạo nên những đợt sóng linh khí khủng khiếp!`
        ];
        
        const techniques = [
            '🗡️ Kiếm pháp thiên thần',
            '👊 Quyền pháp phá thiên',
            '🔥 Hỏa hệ pháp thuật',
            '❄️ Băng huyền tuyệt học',
            '⚡ Lôi đình cửu tiêu',
            '🌪️ Phong long quyền',
            '🌟 Tinh thần chỉ',
            '💫 Vạn kiếm quy tông'
        ];
        
        const randomDesc = descriptions[Math.floor(Math.random() * descriptions.length)];
        const randomTech1 = techniques[Math.floor(Math.random() * techniques.length)];
        const randomTech2 = techniques[Math.floor(Math.random() * techniques.length)];
        
        return `${randomDesc}\n\n` +
               `**Người thách đấu** thi triển ${randomTech1} (${challengerPower.toLocaleString()} sức mạnh)\n` +
               `**Đối thủ** đáp trả bằng ${randomTech2} (${opponentPower.toLocaleString()} sức mạnh)\n\n` +
               `${winner === 'challenger' ? '🏆 Người thách đấu' : '🏆 Đối thủ'} giành chiến thắng sau một trận đấu kinh thiên động địa!`;
    },
    
    calculateRewards(battleResult, winnerRealmId, loserRealmId) {
        const baseWinExp = config.COMBAT.WIN_EXP_BONUS;
        const baseLoseExp = config.COMBAT.LOSE_EXP_BONUS;
        
        // Bonus theo độ chênh lệch realm
        const realmDifference = Math.abs(winnerRealmId - loserRealmId);
        const difficultyBonus = realmDifference > 0 ? Math.floor(baseWinExp * (realmDifference * 0.2)) : 0;
        
        // Bonus theo độ chênh lệch sức mạnh
        const powerDiffBonus = battleResult.powerDifference < 1000 ? 
            Math.floor(baseWinExp * 0.5) : 0; // Bonus cho trận đấu cân bằng
        
        return {
            winnerExp: baseWinExp + difficultyBonus + powerDiffBonus,
            loserExp: baseLoseExp,
            winnerResources: {
                linhKhi: 100 + (realmDifference * 50),
                linhThach: 50 + (realmDifference * 25),
                danDuoc: Math.floor(Math.random() * 3) + 1
            }
        };
    },
    
    createBattleResultEmbed(message, challenger, opponent, battleResult, rewards) {
        const challengerUser = message.client.users.cache.get(challenger.userId);
        const opponentUser = message.client.users.cache.get(opponent.userId);
        
        const winner = battleResult.winner === 'challenger' ? challenger : opponent;
        const loser = battleResult.winner === 'challenger' ? opponent : challenger;
        const winnerUser = battleResult.winner === 'challenger' ? challengerUser : opponentUser;
        const loserUser = battleResult.winner === 'challenger' ? opponentUser : challengerUser;
        
        const winnerRealm = realms.getRealmById(winner.realmId);
        const loserRealm = realms.getRealmById(loser.realmId);
        
        const embed = new EmbedBuilder()
            .setColor(realms.getRealmColor(winnerRealm.tier))
            .setTitle('⚔️ Kết Quả Chiến Đấu ⚔️')
            .setDescription(battleResult.battleDescription)
            .addFields(
                {
                    name: '🏆 Người Chiến Thắng',
                    value: `${realms.formatRealm(winnerRealm)} **${winnerUser.username}**\n+${rewards.winnerExp} EXP`,
                    inline: true
                },
                {
                    name: '💔 Người Thất Bại',
                    value: `${realms.formatRealm(loserRealm)} **${loserUser.username}**\n+${rewards.loserExp} EXP`,
                    inline: true
                },
                {
                    name: '🎁 Phần Thưởng',
                    value: `⚡ +${rewards.winnerResources.linhKhi} Linh Khí\n💰 +${rewards.winnerResources.linhThach} Linh Thạch\n💊 +${rewards.winnerResources.danDuoc} Đan Dược`,
                    inline: false
                }
            )
            .setTimestamp()
            .setFooter({ text: '💡 Sử dụng !tuluyen để tăng sức mạnh!' });
        
        return embed;
    }
};
