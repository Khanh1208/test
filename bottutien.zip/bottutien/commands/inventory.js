const { EmbedBuilder } = require('discord.js');
const db = require('../utils/database');
const { getItemById, formatItem, createItemEmbed } = require('../utils/items');

/**
 * Lệnh xem kho đồ !kho
 */
function handleInventoryCommand(message, args) {
    const userId = message.author.id;
    
    // Kiểm tra đã đăng ký chưa
    if (!db.userExists(userId)) {
        return message.reply('❌ Bạn chưa đăng ký! Sử dụng lệnh `!dk` để đăng ký.');
    }
    
    const inventory = db.getUserInventory(userId);
    const equipment = db.getUserEquipment(userId);
    
    // Tạo embed hiển thị kho đồ
    const embed = new EmbedBuilder()
        .setColor(0x00AE86)
        .setTitle('🎒 Kho Đồ')
        .setDescription(`<@${userId}> - Danh sách vật phẩm`);

    // Hiển thị trang bị hiện tại
    let equipmentText = '';
    if (equipment.weapon) {
        const weapon = getItemById(equipment.weapon);
        equipmentText += `⚔️ **Vũ Khí:** ${formatItem(weapon)}\n`;
    } else {
        equipmentText += '⚔️ **Vũ Khí:** *Chưa trang bị*\n';
    }
    
    if (equipment.armor) {
        const armor = getItemById(equipment.armor);
        equipmentText += `🛡️ **Áo Giáp:** ${formatItem(armor)}\n`;
    } else {
        equipmentText += '🛡️ **Áo Giáp:** *Chưa trang bị*\n';
    }
    
    if (equipment.treasure) {
        const treasure = getItemById(equipment.treasure);
        equipmentText += `💎 **Bảo Vật:** ${formatItem(treasure)}\n`;
    } else {
        equipmentText += '💎 **Bảo Vật:** *Chưa trang bị*\n';
    }
    
    embed.addFields({
        name: '⚡ Trang Bị Hiện Tại',
        value: equipmentText || 'Chưa có trang bị nào',
        inline: false
    });

    // Hiển thị vật phẩm trong kho
    const inventoryItems = Object.keys(inventory);
    
    if (inventoryItems.length === 0) {
        embed.addFields({
            name: '📦 Kho Vật Phẩm',
            value: 'Kho đồ trống',
            inline: false
        });
    } else {
        // Phân loại vật phẩm
        const categories = {
            weapons: [],
            armor: [],
            pills: [],
            materials: [],
            treasures: []
        };
        
        inventoryItems.forEach(itemId => {
            const item = getItemById(parseInt(itemId));
            const quantity = inventory[itemId];
            
            if (item) {
                const itemText = `${formatItem(item, quantity)}`;
                
                switch (item.type) {
                    case 'weapon':
                        categories.weapons.push(itemText);
                        break;
                    case 'armor':
                        categories.armor.push(itemText);
                        break;
                    case 'pill':
                        categories.pills.push(itemText);
                        break;
                    case 'material':
                        categories.materials.push(itemText);
                        break;
                    case 'treasure':
                        categories.treasures.push(itemText);
                        break;
                }
            }
        });
        
        // Hiển thị từng loại
        if (categories.weapons.length > 0) {
            embed.addFields({
                name: '⚔️ Vũ Khí',
                value: categories.weapons.join('\n'),
                inline: true
            });
        }
        
        if (categories.armor.length > 0) {
            embed.addFields({
                name: '🛡️ Áo Giáp',
                value: categories.armor.join('\n'),
                inline: true
            });
        }
        
        if (categories.treasures.length > 0) {
            embed.addFields({
                name: '💎 Bảo Vật',
                value: categories.treasures.join('\n'),
                inline: true
            });
        }
        
        if (categories.pills.length > 0) {
            embed.addFields({
                name: '💊 Đan Dược',
                value: categories.pills.join('\n'),
                inline: true
            });
        }
        
        if (categories.materials.length > 0) {
            embed.addFields({
                name: '🌿 Nguyên Liệu',
                value: categories.materials.join('\n'),
                inline: true
            });
        }
    }

    // Hướng dẫn sử dụng
    embed.addFields({
        name: '📖 Hướng Dẫn',
        value: '• `!item <id>` - Xem chi tiết vật phẩm\n• `!equip <id>` - Trang bị vật phẩm\n• `!unequip <slot>` - Bỏ trang bị',
        inline: false
    });
    
    embed.setFooter({ text: `Tổng cộng: ${inventoryItems.length} loại vật phẩm` });
    
    return message.reply({ embeds: [embed] });
}

/**
 * Lệnh xem chi tiết vật phẩm !item <id>  
 */
function handleItemDetailCommand(message, args) {
    const userId = message.author.id;
    
    if (!db.userExists(userId)) {
        return message.reply('❌ Bạn chưa đăng ký! Sử dụng lệnh `!dk` để đăng ký.');
    }
    
    const itemId = parseInt(args[0]);
    if (!itemId) {
        return message.reply('❌ Vui lòng nhập ID vật phẩm! Ví dụ: `!item 1`');
    }
    
    const item = getItemById(itemId);
    if (!item) {
        return message.reply('❌ Không tìm thấy vật phẩm với ID này!');
    }
    
    const embed = createItemEmbed(item);
    
    // Kiểm tra có trong kho không
    const inventory = db.getUserInventory(userId);
    if (inventory[itemId]) {
        embed.addFields([{
            name: '📦 Trong Kho',
            value: `x${inventory[itemId]}`,
            inline: true
        }]);
    }
    
    return message.reply({ embeds: [embed] });
}

/**
 * Lệnh trang bị !equip <id>
 */
function handleEquipCommand(message, args) {
    const userId = message.author.id;
    
    if (!db.userExists(userId)) {
        return message.reply('❌ Bạn chưa đăng ký! Sử dụng lệnh `!dk` để đăng ký.');
    }
    
    const itemId = parseInt(args[0]);
    if (!itemId) {
        return message.reply('❌ Vui lòng nhập ID vật phẩm! Ví dụ: `!equip 1`');
    }
    
    const item = getItemById(itemId);
    if (!item) {
        return message.reply('❌ Không tìm thấy vật phẩm với ID này!');
    }
    
    if (!db.hasItemInInventory(userId, itemId)) {
        return message.reply('❌ Bạn không có vật phẩm này trong kho!');
    }
    
    // Xác định slot trang bị
    let slot = null;
    switch (item.type) {
        case 'weapon':
            slot = 'weapon';
            break;
        case 'armor':
            slot = 'armor';
            break;
        case 'treasure':
            slot = 'treasure';
            break;
        default:
            return message.reply('❌ Vật phẩm này không thể trang bị!');
    }
    
    const success = db.equipItem(userId, itemId, slot);
    if (success) {
        return message.reply(`✅ Đã trang bị ${formatItem(item)} thành công!`);
    } else {
        return message.reply('❌ Không thể trang bị vật phẩm này!');
    }
}

/**
 * Lệnh bỏ trang bị !unequip <slot>
 */
function handleUnequipCommand(message, args) {
    const userId = message.author.id;
    
    if (!db.userExists(userId)) {
        return message.reply('❌ Bạn chưa đăng ký! Sử dụng lệnh `!dk` để đăng ký.');
    }
    
    const slot = args[0];
    if (!slot || !['weapon', 'armor', 'treasure'].includes(slot)) {
        return message.reply('❌ Vui lòng nhập slot hợp lệ: `weapon`, `armor`, hoặc `treasure`');
    }
    
    const equipment = db.getUserEquipment(userId);
    if (!equipment[slot]) {
        return message.reply('❌ Bạn chưa trang bị gì ở slot này!');
    }
    
    const item = getItemById(equipment[slot]);
    const success = db.unequipItem(userId, slot);
    
    if (success) {
        return message.reply(`✅ Đã bỏ trang bị ${formatItem(item)} thành công!`);
    } else {
        return message.reply('❌ Không thể bỏ trang bị!');
    }
}

module.exports = {
    handleInventoryCommand,
    handleItemDetailCommand,
    handleEquipCommand,
    handleUnequipCommand
};