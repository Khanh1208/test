const { EmbedBuilder } = require("discord.js");
const db = require("../utils/database");
const { getItemById, formatItem } = require("../utils/items");

// Danh sách admin (có thể config trong file riêng)
const ADMIN_IDS = [
    "694925660640116776", // Add your Discord ID here - can be found by using !userinfo or checking logs
    // Thêm Discord ID của admin khác vào đây nếu cần
];

/**
 * Kiểm tra quyền admin
 */
function isAdmin(userId) {
    return ADMIN_IDS.includes(userId);
}

/**
 * Lệnh admin tặng vật phẩm !give @user id amount
 */
function handleGiveCommand(message, args) {
    const adminId = message.author.id;

    // Kiểm tra quyền admin
    if (!isAdmin(adminId)) {
        return message.reply("❌ Bạn không có quyền sử dụng lệnh này!");
    }

    // Parse arguments
    const mention = message.mentions.users.first();
    const itemId = parseInt(args[1]);
    const amount = parseInt(args[2]) || 1;

    if (!mention) {
        return message.reply(
            "❌ Vui lòng mention người dùng! Ví dụ: `!give @user 1 5`",
        );
    }

    if (!itemId) {
        return message.reply(
            "❌ Vui lòng nhập ID vật phẩm! Ví dụ: `!give @user 1 5`",
        );
    }

    if (amount < 1 || amount > 999) {
        return message.reply("❌ Số lượng phải từ 1 đến 999!");
    }

    const userId = mention.id;

    // Kiểm tra người dùng đã đăng ký chưa
    if (!db.userExists(userId)) {
        return message.reply("❌ Người dùng này chưa đăng ký!");
    }

    const item = getItemById(itemId);
    if (!item) {
        return message.reply("❌ Không tìm thấy vật phẩm với ID này!");
    }

    // Thêm vật phẩm vào kho người dùng
    const success = db.addItemToInventory(userId, itemId, amount);

    if (success) {
        const quantityText = amount > 1 ? ` x${amount}` : "";

        // Gửi thông báo cho admin
        message.reply(
            `✅ Đã tặng ${formatItem(item)}${quantityText} cho <@${userId}> thành công!`,
        );

        // Gửi thông báo riêng cho người nhận (nếu có thể)
        mention
            .send(
                `🎁 **Bạn nhận được quà từ Admin!**\n${formatItem(item)}${quantityText} đã được thêm vào kho đồ của bạn.`,
            )
            .catch(() => {
                // Người dùng tắt DM, không làm gì
            });

        return;
    } else {
        return message.reply("❌ Có lỗi xảy ra khi tặng vật phẩm!");
    }
}

/**
 * Lệnh admin tặng tài nguyên !giveres @user type amount
 */
function handleGiveResourceCommand(message, args) {
    const adminId = message.author.id;

    if (!isAdmin(adminId)) {
        return message.reply("❌ Bạn không có quyền sử dụng lệnh này!");
    }

    const mention = message.mentions.users.first();
    const resourceType = args[1]?.toLowerCase();
    const amount = parseInt(args[2]);

    if (!mention) {
        return message.reply(
            "❌ Vui lòng mention người dùng! Ví dụ: `!giveres @user linhthach 1000`",
        );
    }

    if (
        !resourceType ||
        !["linhkhi", "linhthach", "danduoc"].includes(resourceType)
    ) {
        return message.reply(
            "❌ Loại tài nguyên không hợp lệ! Sử dụng: `linhkhi`, `linhthach`, hoặc `danduoc`",
        );
    }

    if (!amount || amount < 1) {
        return message.reply("❌ Số lượng phải lớn hơn 0!");
    }

    const userId = mention.id;

    if (!db.userExists(userId)) {
        return message.reply("❌ Người dùng này chưa đăng ký!");
    }

    // Map tên tài nguyên
    const resourceMap = {
        linhkhi: "linhKhi",
        linhthach: "linhThach",
        danduoc: "danDuoc",
    };

    const resourceKey = resourceMap[resourceType];
    const resources = {};
    resources[resourceKey] = amount;

    const success = db.addResources(userId, resources);

    if (success) {
        const resourceNames = {
            linhKhi: "Linh Khí",
            linhThach: "Linh Thạch",
            danDuoc: "Đan Dược",
        };

        const resourceName = resourceNames[resourceKey];

        message.reply(
            `✅ Đã tặng ${amount.toLocaleString()} ${resourceName} cho <@${userId}> thành công!`,
        );

        mention
            .send(
                `🎁 **Bạn nhận được quà từ Admin!**\n+${amount.toLocaleString()} ${resourceName}`,
            )
            .catch(() => {});

        return;
    } else {
        return message.reply("❌ Có lỗi xảy ra khi tặng tài nguyên!");
    }
}

/**
 * Lệnh xem thông tin người dùng (admin) !userinfo @user
 */
function handleUserInfoCommand(message, args) {
    const adminId = message.author.id;

    if (!isAdmin(adminId)) {
        return message.reply("❌ Bạn không có quyền sử dụng lệnh này!");
    }

    const mention = message.mentions.users.first();
    if (!mention) {
        return message.reply(
            "❌ Vui lòng mention người dùng! Ví dụ: `!userinfo @user`",
        );
    }

    const userId = mention.id;

    if (!db.userExists(userId)) {
        return message.reply("❌ Người dùng này chưa đăng ký!");
    }

    const user = db.getUser(userId);
    const inventory = db.getUserInventory(userId);
    const equipment = db.getUserEquipment(userId);

    const embed = new EmbedBuilder()
        .setColor(0xff0000)
        .setTitle("🔍 Thông Tin Người Dùng (Admin)")
        .setDescription(`**Người dùng:** <@${userId}>`)
        .addFields(
            {
                name: "⭐ Cảnh Giới",
                value: `${user.realmId} - Level ${user.level}`,
                inline: true,
            },
            {
                name: "💫 Kinh Nghiệm",
                value: user.experience.toLocaleString(),
                inline: true,
            },
            {
                name: "💰 Tài Nguyên",
                value: `Linh Khí: ${user.resources.linhKhi.toLocaleString()}\nLinh Thạch: ${user.resources.linhThach.toLocaleString()}\nĐan Dược: ${user.resources.danDuoc.toLocaleString()}`,
                inline: true,
            },
            {
                name: "📊 Thống Kê",
                value: `Tu luyện: ${user.stats.totalTraining}\nĐột phá: ${user.stats.totalBreakthroughs}\nChiến đấu: ${user.stats.totalCombats}`,
                inline: true,
            },
        );

    // Hiển thị kho đồ
    const itemCount = Object.keys(inventory).length;
    embed.addFields({
        name: "🎒 Kho Đồ",
        value: `${itemCount} loại vật phẩm`,
        inline: true,
    });

    // Hiển thị trang bị
    let equipText = "";
    if (equipment.weapon) equipText += `Vũ khí: ${equipment.weapon}\n`;
    if (equipment.armor) equipText += `Áo giáp: ${equipment.armor}\n`;
    if (equipment.treasure) equipText += `Bảo vật: ${equipment.treasure}`;

    embed.addFields({
        name: "⚡ Trang Bị",
        value: equipText || "Chưa có",
        inline: true,
    });

    embed.setFooter({ text: `ID: ${userId}` });

    return message.reply({ embeds: [embed] });
}

/**
 * Lệnh reset người dùng (admin) !resetuser @user
 */
function handleResetUserCommand(message, args) {
    const adminId = message.author.id;

    if (!isAdmin(adminId)) {
        return message.reply("❌ Bạn không có quyền sử dụng lệnh này!");
    }

    const mention = message.mentions.users.first();
    if (!mention) {
        return message.reply(
            "❌ Vui lòng mention người dùng! Ví dụ: `!resetuser @user`",
        );
    }

    const userId = mention.id;

    if (!db.userExists(userId)) {
        return message.reply("❌ Người dùng này chưa đăng ký!");
    }

    // Xóa và tạo lại user với dữ liệu mặc định
    db.deleteUser(userId);
    // User sẽ được tạo lại khi sử dụng lệnh tiếp theo

    return message.reply(`✅ Đã reset dữ liệu của <@${userId}> thành công!`);
}

module.exports = {
    isAdmin,
    handleGiveCommand,
    handleGiveResourceCommand,
    handleUserInfoCommand,
    handleResetUserCommand,
    ADMIN_IDS,
};
