const { EmbedBuilder } = require('discord.js');
const db = require('../utils/database');
const { getItemById, getItemsByType, ITEM_TYPES } = require('../utils/items');

/**
 * Lệnh sử dụng đan dược !sudung <id> [số lượng]
 */
function handleUseMedicineCommand(message, args) {
    const userId = message.author.id;
    
    if (!db.userExists(userId)) {
        return message.reply('❌ Bạn chưa đăng ký! Sử dụng lệnh `!dk` để đăng ký.');
    }
    
    const itemId = parseInt(args[0]);
    const quantity = parseInt(args[1]) || 1;
    
    if (!itemId) {
        return message.reply('❌ Vui lòng nhập ID đan dược! Ví dụ: `!sudung 21`\nSử dụng `!kho` để xem đan dược trong kho.');
    }
    
    if (quantity < 1 || quantity > 10) {
        return message.reply('❌ Số lượng phải từ 1 đến 10!');
    }
    
    const item = getItemById(itemId);
    if (!item || item.type !== ITEM_TYPES.PILL) {
        return message.reply('❌ Không tìm thấy đan dược với ID này!');
    }
    
    // Kiểm tra có trong kho không
    if (!db.hasItemInInventory(userId, itemId, quantity)) {
        return message.reply(`❌ Bạn không có đủ **${item.name}** trong kho!\nCần: ${quantity}x, có: ${db.getUserInventory(userId)[itemId] || 0}x`);
    }
    
    const user = db.getUser(userId);
    
    // Áp dụng hiệu ứng đan dược
    let effectText = '';
    let totalEffects = {
        experience: 0,
        linhKhi: 0,
        linhThach: 0,
        danDuoc: 0
    };
    
    for (let i = 0; i < quantity; i++) {
        const effects = applyMedicineEffect(user, item);
        totalEffects.experience += effects.experience || 0;
        totalEffects.linhKhi += effects.linhKhi || 0;
        totalEffects.linhThach += effects.linhThach || 0;
        totalEffects.danDuoc += effects.danDuoc || 0;
    }
    
    // Cập nhật tài nguyên
    if (totalEffects.experience > 0) {
        user.experience += totalEffects.experience;
    }
    if (totalEffects.linhKhi > 0 || totalEffects.linhThach > 0 || totalEffects.danDuoc > 0) {
        db.addResources(userId, {
            linhKhi: totalEffects.linhKhi,
            linhThach: totalEffects.linhThach,
            danDuoc: totalEffects.danDuoc
        });
    }
    
    // Xóa đan dược khỏi kho
    db.removeItemFromInventory(userId, itemId, quantity);
    
    // Lưu thay đổi
    db.saveUser(user);
    
    // Tạo thông báo hiệu ứng
    let effectDetails = [];
    if (totalEffects.experience > 0) {
        effectDetails.push(`💫 +${totalEffects.experience.toLocaleString()} EXP`);
    }
    if (totalEffects.linhKhi > 0) {
        effectDetails.push(`⚡ +${totalEffects.linhKhi} Linh Khí`);
    }
    if (totalEffects.linhThach > 0) {
        effectDetails.push(`💎 +${totalEffects.linhThach} Linh Thạch`);
    }
    if (totalEffects.danDuoc > 0) {
        effectDetails.push(`💊 +${totalEffects.danDuoc} Đan Dược`);
    }
    
    const embed = new EmbedBuilder()
        .setColor(0x00FF7F)
        .setTitle('💊 Sử Dụng Đan Dược Thành Công!')
        .setDescription(`**${user.userId === message.author.id ? message.author.username : 'Người chơi'}** đã sử dụng ${quantity}x **${item.name}**`)
        .addFields([
            {
                name: '🎯 Hiệu Ứng',
                value: effectDetails.join('\n') || 'Không có hiệu ứng đặc biệt',
                inline: false
            },
            {
                name: '📊 Thông Tin',
                value: `💊 Đã dùng: ${quantity}x\n📦 Còn lại: ${(db.getUserInventory(userId)[itemId] || 0)}x`,
                inline: true
            }
        ])
        .setFooter({ text: 'Hiệu ứng đã được áp dụng vào tài khoản của bạn!' });
    
    return message.reply({ embeds: [embed] });
}

/**
 * Áp dụng hiệu ứng của một viên đan dược
 */
function applyMedicineEffect(user, item) {
    const effects = {};
    
    switch (item.id) {
        case 21: // Tiểu Hoàn Đan
            effects.experience = Math.floor(Math.random() * 500) + 200; // 200-700 EXP
            break;
        case 22: // Trung Hoàn Đan
            effects.experience = Math.floor(Math.random() * 1000) + 500; // 500-1500 EXP
            break;
        case 23: // Đại Hoàn Đan
            effects.experience = Math.floor(Math.random() * 2000) + 1000; // 1000-3000 EXP
            break;
        case 24: // Linh Khí Đan
            effects.linhKhi = Math.floor(Math.random() * 100) + 50; // 50-150 Linh Khí
            break;
        case 25: // Thiên Linh Đan
            effects.experience = Math.floor(Math.random() * 1500) + 800; // 800-2300 EXP
            effects.linhKhi = Math.floor(Math.random() * 80) + 40; // 40-120 Linh Khí
            break;
        case 26: // Phá Cảnh Đan
            effects.experience = Math.floor(Math.random() * 3000) + 2000; // 2000-5000 EXP
            effects.linhThach = Math.floor(Math.random() * 50) + 25; // 25-75 Linh Thạch
            break;
        case 27: // Bất Tử Đan
            effects.experience = Math.floor(Math.random() * 5000) + 3000; // 3000-8000 EXP
            effects.linhKhi = Math.floor(Math.random() * 200) + 100; // 100-300 Linh Khí
            effects.linhThach = Math.floor(Math.random() * 100) + 50; // 50-150 Linh Thạch
            break;
        case 28: // Tạo Hóa Đan
            effects.experience = Math.floor(Math.random() * 8000) + 5000; // 5000-13000 EXP
            effects.linhKhi = Math.floor(Math.random() * 300) + 150; // 150-450 Linh Khí
            effects.linhThach = Math.floor(Math.random() * 150) + 75; // 75-225 Linh Thạch
            break;
        default:
            // Đan dược mặc định
            effects.experience = Math.floor(Math.random() * 300) + 100; // 100-400 EXP
            break;
    }
    
    return effects;
}

/**
 * Lệnh xem đan dược !danduoc
 */
function handleViewMedicinesCommand(message) {
    const userId = message.author.id;
    
    if (!db.userExists(userId)) {
        return message.reply('❌ Bạn chưa đăng ký! Sử dụng lệnh `!dk` để đăng ký.');
    }
    
    const inventory = db.getUserInventory(userId);
    const medicines = getItemsByType(ITEM_TYPES.PILL);
    
    // Lọc chỉ những đan dược có trong kho
    const ownedMedicines = medicines.filter(item => inventory[item.id] && inventory[item.id] > 0);
    
    const embed = new EmbedBuilder()
        .setColor(0xFF69B4)
        .setTitle('💊 Đan Dược Của Bạn')
        .setDescription('Danh sách các loại đan dược trong kho:');
    
    if (ownedMedicines.length === 0) {
        embed.addFields([{
            name: '📦 Kho Trống',
            value: 'Bạn chưa có đan dược nào!\n💰 Liên hệ admin để mua đan dược premium.',
            inline: false
        }]);
    } else {
        let medicineList = '';
        ownedMedicines.forEach(item => {
            const quantity = inventory[item.id];
            medicineList += `💊 **ID: ${item.id}** - ${item.name} x${quantity}\n`;
            medicineList += `   └ ${item.description}\n\n`;
        });
        
        embed.addFields([{
            name: '📦 Danh Sách Đan Dược',
            value: medicineList || 'Không có đan dược nào',
            inline: false
        }]);
    }
    
    embed.addFields([{
        name: '📖 Hướng Dẫn Sử Dụng',
        value: '• `!sudung <id> [số lượng]` - Sử dụng đan dược\n• `!item <id>` - Xem chi tiết đan dược\n• Đan dược chỉ mua được bằng tiền thật',
        inline: false
    }]);
    
    embed.setFooter({ text: `Tổng cộng: ${ownedMedicines.length} loại đan dược` });
    
    return message.reply({ embeds: [embed] });
}

module.exports = {
    name: 'medicine',
    description: 'Quản lý và sử dụng đan dược',
    
    async execute(message, args, client) {
        const command = args[0]?.toLowerCase();
        
        if (!command) {
            return handleViewMedicinesCommand(message);
        }
        
        switch (command) {
            case 'use':
            case 'sudung':
                return handleUseMedicineCommand(message, args.slice(1));
            case 'list':
            case 'xem':
                return handleViewMedicinesCommand(message);
            default:
                return message.reply('❌ Lệnh không hợp lệ!\nSử dụng: `!danduoc` hoặc `!sudung <id>`');
        }
    }
};