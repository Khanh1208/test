const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'hotro',
    aliases: ['help', 'trogiup', 'huongdan', 'commands'],
    description: 'Hiển thị danh sách tất cả lệnh và hướng dẫn sử dụng',
    
    async execute(message, args, client) {
        const embed = new EmbedBuilder()
            .setColor(0x00CED1)
            .setTitle('🎮 Hướng Dẫn Bot Tu Tiên 🎮')
            .setDescription('Chào mừng bạn đến với thế giới tu tiên! Dưới đây là tất cả lệnh có thể sử dụng:')
            .addFields(
                {
                    name: '🧘‍♂️ Tu Luyện',
                    value: '`!tuluyen` - Tu luyện để tăng kinh nghiệm và thu thập tài nguyên\n⏰ Cooldown: 30 phút (1800 EXP)\n📅 Giới hạn: 5 lần/ngày (5 giờ)',
                    inline: false
                },
                {
                    name: '🚀 Đột Phá',
                    value: '`!dotpha` - Đột phá lên cảnh giới cao hơn\n`!dotpha info` - Xem xác suất đột phá chi tiết\n⏰ Cooldown: 8 giờ\n💊 Cần đan dược từ Luyện Khí trở đi',
                    inline: false
                },
                {
                    name: '⚔️ Chiến Đấu',
                    value: '`!chiendau [@user]` - Thách đấu với người khác hoặc tìm đối thủ ngẫu nhiên\n⏰ Cooldown: 30 phút\nAlias: `!chiendat`',
                    inline: false
                },
                {
                    name: '📊 Trạng Thái',
                    value: '`!trangthai [@user]` - Xem thông tin tu vi và tài nguyên\nAlias: `!tt`, `!hoso`, `!profile`',
                    inline: false
                },
                {
                    name: '🏆 Bảng Xếp Hạng',
                    value: '`!bxh [loại]` - Xem bảng xếp hạng\n• `!bxh tuvi` - Xếp hạng theo tu vi\n• `!bxh exp` - Xếp hạng theo kinh nghiệm\n• `!bxh thang` - Xếp hạng theo số trận thắng\n• `!bxh chiendat` - Xếp hạng theo tỷ lệ thắng',
                    inline: false
                },
                {
                    name: '📝 Đăng Ký',
                    value: '`!dk` - Đăng ký tham gia tu tiên (bắt buộc)\nAlias: `!dangky`, `!register`, `!join`',
                    inline: false
                },
                {
                    name: '🎒 Kho Đồ & Trang Bị',
                    value: '`!kho` - Xem kho đồ và trang bị\n`!item <id>` - Xem chi tiết vật phẩm\n`!equip <id>` - Trang bị vật phẩm\n`!unequip <slot>` - Bỏ trang bị\n`!thuoctinh` - Xem chi tiết thuộc tính',
                    inline: false
                },
                {
                    name: '🏪 Cửa Hàng',
                    value: '`!shop [loại]` - Xem cửa hàng\n`!buy <id> [số lượng]` - Mua vật phẩm\n`!sell <id> [số lượng]` - Bán vật phẩm',
                    inline: false
                },
                {
                    name: '💊 Đan Dược',
                    value: '`!danduoc` - Xem đan dược trong kho\n`!sudung <id> [số lượng]` - Sử dụng đan dược\n💰 Đan dược chỉ mua được bằng tiền thật',
                    inline: false
                },
                {
                    name: '❓ Hỗ Trợ',
                    value: '`!hotro` - Hiển thị hướng dẫn này\nAlias: `!help`, `!trogiup`, `!huongdan`, `!commands`',
                    inline: false
                }
            )
            .addFields(
                {
                    name: '🌟 Hệ Thống Tu Vi (28 Cảnh Giới)',
                    value: '**Phàm Nhân** → **Luyện Thể** → **Khai Linh** → **Luyện Khí** → **Trúc Cơ** → **Kim Đan** → **Nguyên Anh** → **Hóa Thần** → **Luyện Hư** → **Hợp Thể** → **Đại Thừa** → **Độ Kiếp** → **Phi Thăng** → **Chân Tiên** → **Kim Tiên** → **Thái Ất Chân Tiên** → **Đại La Kim Tiên** → **Tiên Vương** → **Tiên Đế** → **Bán Thánh** → **Chân Thánh** → **Thánh Vương** → **Thánh Đế** → **Đế Quân** → **Tiên Tổ** → **Hỗn Độn Cảnh** → **Sáng Thế Giả** → **Thiên Đạo**',
                    inline: false
                },
                {
                    name: '💎 Tài Nguyên',
                    value: '• ⚡ **Linh Khí** - Dùng để tu luyện và đột phá\n• 💰 **Linh Thạch** - Tài nguyên quý giá\n• 💊 **Đan Dược** - Tăng tỷ lệ đột phá thành công',
                    inline: false
                },
                {
                    name: '🎯 Mẹo Tu Luyện',
                    value: '• **Bước 1:** Sử dụng `!dk` để đăng ký tham gia\n• **Bước 2:** Tu luyện đều đặn với `!tuluyen` (30 phút/lần)\n• **Bước 3:** Tích trữ tài nguyên trước khi đột phá\n• **Bước 4:** Thách đấu để kiếm thêm kinh nghiệm\n• **Lưu ý:** Kiên nhẫn với việc đột phá - may mắn rất quan trọng!',
                    inline: false
                }
            )
            .setFooter({ text: 'Chúc bạn tu luyện thành công và sớm đạt được Thiên Đạo!' })
            .setTimestamp();

        message.reply({ embeds: [embed] });
    }
};