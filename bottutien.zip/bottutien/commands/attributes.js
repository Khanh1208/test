const { EmbedBuilder } = require('discord.js');
const db = require('../utils/database');
const { getItemById, formatItem } = require('../utils/items');

/**
 * Lệnh xem chi tiết thuộc tính !thuoctinh
 */
function handleAttributesCommand(message, args) {
    const userId = message.author.id;
    
    // Kiểm tra đã đăng ký chưa
    if (!db.userExists(userId)) {
        return message.reply('❌ Bạn chưa đăng ký! Sử dụng lệnh `!dk` để đăng ký.');
    }
    
    const user = db.getUser(userId);
    const attributes = db.calculateTotalAttributes(userId);
    const equipment = db.getUserEquipment(userId);
    
    const embed = new EmbedBuilder()
        .setColor(0x9932CC)
        .setTitle('⚡ Chi Tiết Thuộc Tính')
        .setDescription(`<@${userId}> - Phân tích sức mạnh`)
        .setThumbnail(message.author.displayAvatarURL({ dynamic: true }));
    
    // Thuộc tính tổng cộng
    embed.addFields({
        name: '🎯 Thuộc Tính Tổng Cộng',
        value: `⚔️ **Sức Tấn Công (ATK):** ${attributes.atk}\n🩸 **Sinh Mệnh (HP):** ${attributes.hp}\n🛡️ **Phòng Thủ (Defense):** ${attributes.defense}\n🔮 **Ma Pháp (Mana):** ${attributes.mana}`,
        inline: false
    });
    
    // Phân tích chi tiết
    const breakdown = attributes.breakdown;
    
    embed.addFields({
        name: '📊 Phân Tích Chi Tiết',
        value: `**Thuộc tính cơ bản:**\nATK: ${breakdown.base.atk} | HP: ${breakdown.base.hp} | Defense: ${breakdown.base.defense} | Mana: ${breakdown.base.mana}`,
        inline: false
    });
    
    embed.addFields({
        name: '🌟 Bonus Cảnh Giới',
        value: `**Hệ số:** x${breakdown.realmBonus.multiplier.toFixed(1)}\nATK: +${breakdown.realmBonus.atk} | HP: +${breakdown.realmBonus.hp} | Defense: +${breakdown.realmBonus.defense} | Mana: +${breakdown.realmBonus.mana}`,
        inline: false
    });
    
    // Bonus từ trang bị
    let equipmentText = '';
    if (equipment.weapon) {
        const weapon = getItemById(equipment.weapon);
        equipmentText += `⚔️ **Vũ Khí:** ${formatItem(weapon)} (+${weapon.power || 0} ATK)\n`;
    }
    
    if (equipment.armor) {
        const armor = getItemById(equipment.armor);
        equipmentText += `🛡️ **Áo Giáp:** ${formatItem(armor)} (+${armor.defense || 0} Defense)\n`;
    }
    
    if (equipment.treasure) {
        const treasure = getItemById(equipment.treasure);
        let bonusText = '';
        if (treasure.effect === 'mana_boost') bonusText = `+${treasure.value} Mana`;
        else if (treasure.effect === 'hp_boost') bonusText = `+${treasure.value} HP`;
        else if (treasure.effect === 'qi_regen') bonusText = `+${treasure.value} Linh Khí/giờ`;
        equipmentText += `💎 **Bảo Vật:** ${formatItem(treasure)} (${bonusText})\n`;
    }
    
    if (equipmentText) {
        embed.addFields({
            name: '⚡ Bonus Trang Bị',
            value: equipmentText + `\n**Tổng Bonus:** ATK +${breakdown.equipmentBonus.atk} | Defense +${breakdown.equipmentBonus.defense} | Mana +${breakdown.equipmentBonus.mana}`,
            inline: false
        });
    } else {
        embed.addFields({
            name: '⚡ Bonus Trang Bị',
            value: 'Chưa trang bị vật phẩm nào',
            inline: false
        });
    }
    
    // Tính sức mạnh chiến đấu
    const combatPower = Math.floor((attributes.atk * 2 + attributes.hp + attributes.defense + attributes.mana) / 5);
    embed.addFields({
        name: '💪 Sức Mạnh Chiến Đấu',
        value: `**${combatPower.toLocaleString()}** điểm`,
        inline: false
    });
    
    embed.setFooter({ text: 'Thuộc tính tăng theo cảnh giới và trang bị' });
    
    return message.reply({ embeds: [embed] });
}

module.exports = {
    handleAttributesCommand
};