const { EmbedBuilder } = require('discord.js');
const db = require('../utils/database');
const realms = require('../utils/realms');
const cooldowns = require('../utils/cooldowns');
const config = require('../config');

module.exports = {
    name: 'dotpha',
    aliases: ['breakthrough', 'ascend'],
    description: 'Đột phá lên cảnh giới cao hơn',
    
    async execute(message, args, client) {
        const userId = message.author.id;
        
        // Kiểm tra đã đăng ký chưa
        if (!db.userExists(userId)) {
            return message.reply('❌ Bạn chưa đăng ký tham gia tu tiên!\nSử dụng `!dk` để đăng ký trước khi đột phá.');
        }
        
        // Kiểm tra nếu có tham số 'info' để hiển thị thông tin xác suất
        if (args[0] && args[0].toLowerCase() === 'info') {
            return this.showBreakthroughInfo(message, userId);
        }
        
        const user = db.getUser(userId);
        const currentRealm = realms.getRealmById(user.realmId);
        const nextRealm = realms.getNextRealm(user.realmId);
        
        // Kiểm tra đã đạt max realm chưa
        if (!nextRealm) {
            return message.reply('👑 Bạn đã đạt được cảnh giới cao nhất - Thiên Đạo! Không thể đột phá thêm nữa!');
        }
        
        // Kiểm tra đủ kinh nghiệm chưa
        if (!realms.canBreakthrough(user.experience, user.realmId)) {
            const expNeeded = realms.getExpToNext(user.experience, user.realmId);
            return message.reply(`❌ Chưa đủ kinh nghiệm để đột phá!\nCần thêm **${expNeeded.toLocaleString()} EXP** để đột phá lên **${realms.formatRealm(nextRealm)}**`);
        }
        
        // Kiểm tra cooldown
        const cooldownResult = cooldowns.handleBreakthroughCooldown(userId);
        if (!cooldownResult.canProceed) {
            return message.reply(cooldownResult.message);
        }
        
        // Tính toán tỷ lệ thành công
        const successRate = this.calculateSuccessRate(user, currentRealm, nextRealm);
        const failureRate = (1 - successRate) * 100;
        const isSuccess = Math.random() < successRate;
        
        // Tính chi phí tài nguyên
        const cost = this.calculateBreakthroughCost(user.realmId);
        
        // Kiểm tra đủ tài nguyên không
        if (!this.canAffordCost(user, cost)) {
            return message.reply(this.createInsufficientResourcesMessage(cost));
        }
        
        // Trừ tài nguyên
        db.spendResources(userId, cost);
        
        if (isSuccess) {
            // Đột phá thành công
            user.realmId++;
            user.level = 1;
            user.stats.totalBreakthroughs++;
            
            // Thưởng đột phá
            const rewards = this.calculateBreakthroughRewards(user.realmId);
            db.addResources(userId, rewards);
            
            db.saveUser(user);
            
            const embed = this.createSuccessEmbed(message.author, currentRealm, nextRealm, rewards);
            message.reply({ embeds: [embed] });
        } else {
            // Đột phá thất bại
            const penalty = this.calculateFailurePenalty(user.experience);
            user.experience = Math.max(0, user.experience - penalty);
            
            db.saveUser(user);
            
            const embed = this.createFailureEmbed(message.author, currentRealm, nextRealm, penalty, successRate, failureRate);
            message.reply({ embeds: [embed] });
        }
    },
    
    calculateSuccessRate(user, currentRealm, nextRealm) {
        let baseRate = config.CULTIVATION.BREAKTHROUGH_SUCCESS_RATE;
        
        // Bonus từ kinh nghiệm thừa
        const excessExp = user.experience - nextRealm.baseExp;
        const expBonus = Math.min(0.2, excessExp / nextRealm.baseExp * 0.1);
        
        // Bonus từ tài nguyên
        const resourceBonus = Math.min(0.1, user.resources.danDuoc * 0.01);
        
        // Penalty cho realm cao
        const realmPenalty = Math.max(0, (user.realmId - 10) * 0.02);
        
        // Bonus từ số lần đột phá thành công liên tiếp
        const streakBonus = Math.min(0.05, user.stats.totalBreakthroughs * 0.005);
        
        const finalRate = Math.min(0.95, Math.max(0.1, 
            baseRate + expBonus + resourceBonus + streakBonus - realmPenalty
        ));
        
        return finalRate;
    },
    
    calculateBreakthroughCost(realmId) {
        const baseCost = {
            linhKhi: 500,
            linhThach: 0, // Không cần linh thạch để đột phá
            danDuoc: 0    // Sẽ tính riêng dựa trên cảnh giới
        };
        
        const multiplier = Math.pow(1.5, Math.floor(realmId / 3));
        
        // Đan dược chỉ cần từ cảnh giới thứ 4 (Luyện Khí) trở đi
        let danDuocCost = 0;
        if (realmId >= 3) { // realmId 3 = Luyện Khí (cảnh giới thứ 4, index từ 0)
            danDuocCost = Math.floor(2 * Math.pow(1.2, Math.floor((realmId - 3) / 3)));
        }
        
        return {
            linhKhi: Math.floor(baseCost.linhKhi * multiplier),
            linhThach: 0, // Luôn = 0
            danDuoc: danDuocCost
        };
    },
    
    canAffordCost(user, cost) {
        return user.resources.linhKhi >= cost.linhKhi &&
               user.resources.danDuoc >= cost.danDuoc;
        // Không kiểm tra linhThach vì không cần nữa
    },
    
    createInsufficientResourcesMessage(cost) {
        let message = `❌ Không đủ tài nguyên để đột phá!\n\n**Cần:**\n⚡ ${cost.linhKhi.toLocaleString()} Linh Khí`;
        
        if (cost.danDuoc > 0) {
            message += `\n💊 ${cost.danDuoc} Đan Dược`;
        }
        
        message += `\n\n💡 Sử dụng \`!tuluyen\` để thu thập Linh Khí!`;
        
        if (cost.danDuoc > 0) {
            message += `\n💰 Đan dược chỉ mua được bằng tiền thật - liên hệ admin!`;
        }
        
        return message;
    },
    
    calculateBreakthroughRewards(newRealmId) {
        return {
            linhKhi: 1000 + (newRealmId * 200),
            linhThach: 0, // Không thưởng linh thạch
            danDuoc: 0    // Không thưởng đan dược
        };
    },
    
    calculateFailurePenalty(currentExp) {
        return Math.floor(currentExp * 0.1); // Mất 10% kinh nghiệm
    },
    
    createSuccessEmbed(author, oldRealm, newRealm, rewards) {
        const embed = new EmbedBuilder()
            .setColor(0x00FF00)
            .setTitle('🚀 ĐỘT PHÁ THÀNH CÔNG! 🚀')
            .setDescription(`🎉 **${author.username}** đã đột phá thành công!`)
            .addFields(
                {
                    name: '⬆️ Tiến Bộ Tu Vi',
                    value: `${realms.formatRealm(oldRealm)} ➜ **${realms.formatRealm(newRealm)}**`,
                    inline: false
                },
                {
                    name: '🎁 Phần Thưởng Đột Phá',
                    value: `⚡ +${rewards.linhKhi.toLocaleString()} Linh Khí`,
                    inline: true
                },
                {
                    name: '💫 Lời Chúc',
                    value: `Chúc mừng bạn đã vượt qua thử thách và bước vào cảnh giới mới!\nHãy tiếp tục tu luyện để đạt được đỉnh cao hơn nữa!`,
                    inline: false
                }
            )
            .setThumbnail(author.displayAvatarURL({ dynamic: true }))
            .setTimestamp()
            .setFooter({ text: 'Thiên đạo phù trợ, tu vi tiến bộ!' });
        
        return embed;
    },
    
    createFailureEmbed(author, currentRealm, nextRealm, penalty, successRate, failureRate) {
        const embed = new EmbedBuilder()
            .setColor(0xFF0000)
            .setTitle('💥 ĐỘT PHÁ THẤT BẠI! 💥')
            .setDescription(`😢 **${author.username}** đã thất bại trong việc đột phá...`)
            .addFields(
                {
                    name: '❌ Kết Quả',
                    value: `Vẫn ở cảnh giới **${realms.formatRealm(currentRealm)}**\nKhông thể đột phá lên **${realms.formatRealm(nextRealm)}**`,
                    inline: false
                },
                {
                    name: '📉 Hậu Quả',
                    value: `Mất ${penalty.toLocaleString()} EXP do đột phá thất bại`,
                    inline: true
                },
                {
                    name: '📊 Xác Suất',
                    value: `✅ Thành công: ${(successRate * 100).toFixed(1)}%\n❌ Thất bại: ${failureRate.toFixed(1)}%`,
                    inline: true
                },
                {
                    name: '💡 Lời Khuyên',
                    value: `Đừng nản lòng! Hãy tu luyện thêm để tích lũy kinh nghiệm và tài nguyên.\nSử dụng \`!tuluyen\` để tăng cường sức mạnh!`,
                    inline: false
                }
            )
            .setThumbnail(author.displayAvatarURL({ dynamic: true }))
            .setTimestamp()
            .setFooter({ text: 'Thất bại là mẹ của thành công!' });
        
        return embed;
    },
    
    async showBreakthroughInfo(message, userId) {
        const user = db.getUser(userId);
        const currentRealm = realms.getRealmById(user.realmId);
        const nextRealm = realms.getNextRealm(user.realmId);
        
        // Kiểm tra đã đạt max realm chưa
        if (!nextRealm) {
            return message.reply('👑 Bạn đã đạt được cảnh giới cao nhất - Thiên Đạo! Không thể đột phá thêm nữa!');
        }
        
        // Kiểm tra đủ kinh nghiệm chưa
        if (!realms.canBreakthrough(user.experience, user.realmId)) {
            const expNeeded = realms.getExpToNext(user.experience, user.realmId);
            return message.reply(`❌ Chưa đủ kinh nghiệm để đột phá!\nCần thêm **${expNeeded.toLocaleString()} EXP** để đột phá lên **${realms.formatRealm(nextRealm)}**`);
        }
        
        // Tính toán tỷ lệ thành công
        const successRate = this.calculateSuccessRate(user, currentRealm, nextRealm);
        const failureRate = (1 - successRate) * 100;
        
        // Tính chi phí tài nguyên
        const cost = this.calculateBreakthroughCost(user.realmId);
        const canAfford = this.canAffordCost(user, cost);
        
        // Tính phần thưởng và hình phạt
        const rewards = this.calculateBreakthroughRewards(user.realmId + 1);
        const penalty = this.calculateFailurePenalty(user.experience);
        
        const embed = new EmbedBuilder()
            .setColor(0x9932CC)
            .setTitle('🔮 Thông Tin Đột Phá')
            .setDescription(`📊 **${message.author.username}** - Phân tích xác suất đột phá`)
            .addFields(
                {
                    name: '🚀 Đột Phá',
                    value: `${realms.formatRealm(currentRealm)} ➜ **${realms.formatRealm(nextRealm)}**`,
                    inline: false
                },
                {
                    name: '📊 Xác Suất Thành Công',
                    value: `✅ **${(successRate * 100).toFixed(1)}%** - Đột phá thành công\n❌ **${failureRate.toFixed(1)}%** - Đột phá thất bại`,
                    inline: false
                },
                {
                    name: '💰 Chi Phí Đột Phá',
                    value: cost.danDuoc > 0 
                        ? `⚡ ${cost.linhKhi.toLocaleString()} Linh Khí\n💊 ${cost.danDuoc} Đan Dược`
                        : `⚡ ${cost.linhKhi.toLocaleString()} Linh Khí\n✨ Không cần đan dược (3 cảnh giới đầu)`,
                    inline: true
                },
                {
                    name: '🎁 Phần Thưởng (Nếu Thành Công)',
                    value: `⚡ +${rewards.linhKhi.toLocaleString()} Linh Khí`,
                    inline: true
                },
                {
                    name: '⚠️ Hình Phạt (Nếu Thất Bại)',
                    value: `📉 Mất ${penalty.toLocaleString()} EXP (10% tổng EXP)`,
                    inline: false
                },
                {
                    name: '💡 Các Yếu Tố Ảnh Hưởng',
                    value: this.getFactorsExplanation(user, currentRealm, nextRealm),
                    inline: false
                }
            )
            .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
            .setFooter({ 
                text: canAfford ? 'Sử dụng !dotpha để thực hiện đột phá' : 'Không đủ tài nguyên để đột phá' 
            })
            .setTimestamp();
            
        if (!canAfford) {
            embed.setColor(0xFF0000);
            embed.addFields({
                name: '❌ Thiếu Tài Nguyên',
                value: `Bạn không đủ tài nguyên để đột phá. Hãy tu luyện thêm!`,
                inline: false
            });
        }
        
        return message.reply({ embeds: [embed] });
    },
    
    getFactorsExplanation(user, currentRealm, nextRealm) {
        let explanation = '';
        
        // Base rate
        explanation += `🎯 Tỷ lệ cơ bản: ${(config.CULTIVATION.BREAKTHROUGH_SUCCESS_RATE * 100).toFixed(0)}%\n`;
        
        // Experience bonus
        const excessExp = user.experience - nextRealm.baseExp;
        if (excessExp > 0) {
            const expBonus = Math.min(0.2, excessExp / nextRealm.baseExp * 0.1);
            explanation += `📈 Bonus EXP thừa: +${(expBonus * 100).toFixed(1)}%\n`;
        }
        
        // Resource bonus
        const resourceBonus = Math.min(0.1, user.resources.danDuoc * 0.01);
        if (resourceBonus > 0) {
            explanation += `💊 Bonus Đan Dược: +${(resourceBonus * 100).toFixed(1)}%\n`;
        }
        
        // Realm penalty
        if (user.realmId > 10) {
            const realmPenalty = (user.realmId - 10) * 0.02;
            explanation += `⬇️ Phạt cảnh giới cao: -${(realmPenalty * 100).toFixed(1)}%\n`;
        }
        
        // Breakthrough streak
        if (user.stats.totalBreakthroughs > 0) {
            const streakBonus = Math.min(0.05, user.stats.totalBreakthroughs * 0.005);
            explanation += `🔥 Bonus kinh nghiệm: +${(streakBonus * 100).toFixed(1)}%\n`;
        }
        
        return explanation || 'Chỉ có tỷ lệ cơ bản';
    }
};
