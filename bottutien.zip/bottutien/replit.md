# Discord Cultivation Bot

## Overview

This is a Discord bot that simulates a cultivation system inspired by Chinese xianxia novels. Players can train, breakthrough to higher realms, engage in combat with other players, and progress through 27 different cultivation stages from mortal to divine levels.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Backend Architecture
- **Framework**: Node.js with Discord.js v14
- **Architecture Pattern**: Command-based modular structure
- **Data Storage**: In-memory storage using JavaScript Maps
- **Language**: Vietnamese interface with cultivation terminology

### Key Components

1. **Bot Core** (`index.js`)
   - Discord client initialization
   - Command loading and routing
   - Event handling for messages

2. **Configuration** (`config.js`)
   - Centralized settings for cultivation mechanics
   - Cooldown timers and resource multipliers
   - Combat and progression parameters

3. **Command System** (`commands/`)
   - Modular command structure
   - Individual files for each game feature
   - Shared utilities for consistent behavior

4. **Utility Modules** (`utils/`)
   - Database operations
   - Cultivation realm definitions
   - Cooldown management

### Data Flow

1. **User Registration**: Automatic user creation on first interaction
2. **Command Processing**: Prefix-based command parsing and execution
3. **State Management**: In-memory user data with real-time updates
4. **Progress Tracking**: Experience, resources, and statistics tracking

### Core Game Mechanics

#### Cultivation System
- **27 Cultivation Realms**: From mortal to divine levels
- **Experience Progression**: Base EXP with multipliers and bonuses
- **Resource Management**: Spirit Qi, Spirit Stones, and Pills
- **Breakthrough System**: Realm advancement with success rates

#### Combat System
- **Player vs Player**: Direct challenges between users
- **Random Opponents**: Automatic matching based on realm proximity
- **Power Calculation**: Realm-based combat strength
- **Rewards**: Experience and resources for participation

#### Cooldown Management
- **Training**: 4-hour cooldown between cultivation sessions
- **Breakthrough**: 8-hour cooldown for realm advancement
- **Combat**: 30-minute cooldown between fights

### External Dependencies

- **discord.js**: Discord API integration for bot functionality
- **Node.js**: Runtime environment for server-side JavaScript

### Deployment Strategy

- **Environment**: Node.js environment with Discord bot token
- **Configuration**: Environment variables for sensitive data
- **Startup**: Single entry point through index.js
- **Scaling**: In-memory storage suitable for small to medium communities

### Database Schema (In-Memory)

#### User Data Structure
```javascript
{
  userId: String,           // Discord user ID
  realmId: Number,         // Current cultivation realm (0-27)
  experience: Number,      // Total experience points
  level: Number,           // Level within current realm
  resources: {
    linhKhi: Number,       // Spirit Qi
    linhThach: Number,     // Spirit Stones
    danDuoc: Number        // Pills
  },
  stats: {
    totalTraining: Number,
    totalBreakthroughs: Number,
    totalCombats: Number,
    winsCount: Number,
    lossesCount: Number,
    consecutiveWins: Number
  },
  timestamps: {
    lastTraining: Number,
    lastBreakthrough: Number,
    lastCombat: Number,
    joined: Number
  }
}
```

#### Cultivation Realms (Updated)
The system now uses the exact 28 cultivation realms as specified by the user:
1. Phàm Nhân (200 baseExp)
2. Luyện Thể (400 baseExp)
3. Khai Linh (800 baseExp)
4. Luyện Khí (1,000 baseExp)
5. Trúc Cơ (3,000 baseExp)
6. Kim Đan (10,000 baseExp)
...continuing up to...
28. Thiên Đạo (30,000,000,000 baseExp)

### Recent Changes (2025-01-23)
- Updated cultivation realms to match user's exact specifications (28 realms)
- Fixed baseExp vs expRequired property inconsistencies
- Bot successfully connected to Discord with provided token
- All core commands functional: !tuluyen, !dotpha, !chiendat, !trangthai, !bxh, !help
- **NEW:** Added !dk (registration) command - users must register before using bot features
- **IMPROVED:** Updated !tuluyen interface with progress bars and better styling
- **IMPROVED:** Updated !trangthai interface to match user's requested design
- Added registration requirement for all cultivation commands
- Enhanced emoji and color support for all 28 cultivation realms

### Future Considerations

- **Persistent Storage**: Current in-memory storage will lose data on restart
- **Database Integration**: Consider adding PostgreSQL with Drizzle ORM for data persistence
- **Scalability**: Memory usage grows with user base
- **Backup Strategy**: No current data backup mechanism