module.exports = {
    PREFIX: '!',
    TOKEN: process.env.DISCORD_TOKEN || 'MTM3NjExODEwOTM3ODg0MjcxNA.GrRUfA.xKFeEQZobnAhClGCYHOHE3BYI_qgFspugBoDz4',
    
    // Cài đặt tu luyện
    CULTIVATION: {
        // Thời gian cooldown (miligiây)
        TRAINING_COOLDOWN: 30 * 60 * 1000, // 30 phút
        BREAKTHROUGH_COOLDOWN: 8 * 60 * 60 * 1000, // 8 giờ
        COMBAT_COOLDOWN: 60 * 60 * 1000, // 1 giờ
        
        // Giới hạn tu luyện hàng ngày
        MAX_TRAINING_PER_DAY: 5, // Tối đa 5 lần tu luyện/ngày (5 giờ)
        
        // Kinh nghiệm cơ bản
        BASE_EXP_GAIN: 100,
        EXP_MULTIPLIER: 1.5,
        
        // Tài nguyên ban đầu
        STARTING_RESOURCES: {
            LINH_KHI: 1000,
            LINH_THACH: 500,
            DAN_DUOC: 3
        },
        
        // Tỷ lệ thành công đột phá
        BREAKTHROUGH_SUCCESS_RATE: 0.5, // 50% cơ bản
        
        // Bonus kinh nghiệm ngẫu nhiên
        RANDOM_EXP_BONUS: {
            MIN: 0.8,  // Tỷ lệ ngẫu nhiên từ 0.8 đến 1.5
            MAX: 1.5  // Tỷ lệ ngẫu nhiên từ 0.8 đến 1.5
        },
        
        // Tài nguyên ngẫu nhiên khi tu luyện
        RANDOM_RESOURCES: {
            LINH_KHI: { MIN: 20, MAX: 50 },  // Tài nguyên linh khí ngẫu nhiên
            LINH_THACH: { MIN: 5, MAX: 20 }  // Tài nguyên linh thạch ngẫu nhiên
        }
    },
    
    // Cài đặt chiến đấu
    COMBAT: {
        POWER_MULTIPLIER: 100,  //Hệ số nhân sức mạnh khi tính toán sát thương hoặc điểm sức mạnh tổng
        REALM_BONUS: 50,      //Bonus điểm sức mạnh hoặc sát thương dựa trên chênh lệch cảnh giới giữa hai người chơi
        WIN_EXP_BONUS: 150,   //Số EXP thưởng cho người thắng trận đấu
        LOSE_EXP_BONUS: 50   //Số EXP (hoặc bị trừ nếu bạn đã chỉnh) cho người thua trận đấu
    }
};

