const { Client, GatewayIntentBits } = require("discord.js");
const config = require("./config");

// Import command handlers
const cultivationCommand = require("./commands/cultivation");
const breakthroughCommand = require("./commands/breakthrough");
const statusCommand = require("./commands/status");
const combatCommand = require("./commands/combat");
const leaderboardCommand = require("./commands/leaderboard");
const registerCommand = require("./commands/register");
const helpCommand = require("./commands/help");
const {
    handleInventoryCommand,
    handleItemDetailCommand,
    handleEquipCommand,
    handleUnequipCommand,
} = require("./commands/inventory");
const {
    handleShopCommand,
    handleBuyCommand,
    handleSellCommand,
} = require("./commands/shop");
const {
    handleGiveCommand,
    handleGiveResourceCommand,
    handleUserInfoCommand,
    handleResetUserCommand,
} = require("./commands/admin");
const { handleAttributesCommand } = require("./commands/attributes");
const medicineCommand = require("./commands/medicine");
require("./keep_alive.js"); // ✅ ĐÚNG
// Khởi tạo Discord client
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
    ],
});

// Map để theo dõi các message đã xử lý (tránh xử lý trùng)
const processedMessages = new Map();

// Event khi bot sẵn sàng
client.once("ready", () => {
    console.log(`🚀 Bot ${client.user.tag} đã kết nối thành công!`);
    console.log(`📊 Đang phục vụ ${client.guilds.cache.size} server(s)`);

    // Set bot status
    client.user.setActivity("Tu luyện thành tiên ⚡ | !help", {
        type: "PLAYING",
    });

    // Dọn dẹp map processedMessages mỗi 5 phút
    setInterval(
        () => {
            const now = Date.now();
            const fiveMinutesAgo = now - 5 * 60 * 1000;

            for (const [key, timestamp] of processedMessages.entries()) {
                if (timestamp < fiveMinutesAgo) {
                    processedMessages.delete(key);
                }
            }
        },
        5 * 60 * 1000,
    );
});

// Event xử lý tin nhắn
client.on("messageCreate", async (message) => {
    // Bỏ qua tin nhắn từ bot
    if (message.author.bot) return;

    // Kiểm tra prefix
    if (!message.content.startsWith(config.PREFIX)) return;

    // Kiểm tra message đã được xử lý chưa (tránh duplicate)
    const messageKey = `${message.author.id}-${message.content}-${message.createdTimestamp}`;
    if (processedMessages.has(messageKey)) {
        console.log(`⚠️ Duplicate message detected: ${messageKey}`);
        return;
    }

    // Đánh dấu message đã xử lý
    processedMessages.set(messageKey, Date.now());

    // Parse command và arguments
    const args = message.content.slice(config.PREFIX.length).trim().split(/ +/);
    const commandName = args.shift().toLowerCase();

    try {
        // Xử lý các lệnh
        switch (commandName) {
            // Lệnh cơ bản
            case "dk":
            case "dangky":
                await registerCommand.execute(message, args, client);
                break;

            case "tuluyen":
            case "tl":
                await cultivationCommand.execute(message, args, client);
                break;

            case "dotpha":
            case "breakthrough":
            case "ascend":
                await breakthroughCommand.execute(message, args, client);
                break;

            case "trangthai":
            case "tt":
                await statusCommand.execute(message, args, client);
                break;

            case "chiendau":
            case "cd":
                await combatCommand.execute(message, args, client);
                break;

            case "bxh":
            case "bangxephang":
                await leaderboardCommand.execute(message, args, client);
                break;

            case "hotro":
            case "help":
            case "h":
            case "trogiup":
            case "huongdan":
            case "commands":
                await helpCommand.execute(message, args, client);
                break;

            // Lệnh kho đồ
            case "kho":
            case "inventory":
                await handleInventoryCommand(message, args);
                break;

            case "item":
                await handleItemDetailCommand(message, args);
                break;

            case "equip":
            case "trangbi":
                await handleEquipCommand(message, args);
                break;

            case "unequip":
            case "botrangbi":
                await handleUnequipCommand(message, args);
                break;

            // Lệnh shop
            case "shop":
            case "cuahang":
                await handleShopCommand(message, args);
                break;

            case "buy":
            case "mua":
                await handleBuyCommand(message, args);
                break;

            case "sell":
            case "ban":
                await handleSellCommand(message, args);
                break;

            // Lệnh admin
            case "give":
                await handleGiveCommand(message, args);
                break;

            case "giveres":
            case "givetainguyen":
                await handleGiveResourceCommand(message, args);
                break;

            case "userinfo":
            case "thongtinnguoidung":
                await handleUserInfoCommand(message, args);
                break;

            case "resetuser":
            case "resetnguoidung":
                await handleResetUserCommand(message, args);
                break;

            // Lệnh thuộc tính
            case "thuoctinh":
            case "attributes":
            case "stats":
                await handleAttributesCommand(message, args);
                break;

            // Lệnh đan dược
            case "danduoc":
            case "medicine":
            case "pill":
                await medicineCommand.execute(message, args, client);
                break;

            case "sudung":
            case "use":
                await medicineCommand.execute(
                    message,
                    ["sudung", ...args],
                    client,
                );
                break;

            default:
                // Không làm gì nếu lệnh không tồn tại
                break;
        }
    } catch (error) {
        console.error(`❌ Lỗi khi thực thi command ${commandName}:`, error);
        message.reply("❌ Có lỗi xảy ra khi thực thi lệnh này!");
    }
});

// Event xử lý lỗi
client.on("error", (error) => {
    console.error("❌ Discord client error:", error);
});

process.on("unhandledRejection", (error) => {
    console.error("❌ Unhandled promise rejection:", error);
});

client.once('ready', () => {
    console.log(`Bot đã online với tên ${client.user.tag}!`);
    const channel = client.channels.cache.get(''); // Thay bằng ID kênh của bạn
    if (channel) {
        channel.send(
            '🌌 Thiên đạo vận chuyển, vạn vật hồi sinh... Tu Tiên Giới đã mở!\n' +
            '🐉 Linh khí hội tụ, chư vị đạo hữu, hãy bắt đầu hành trình tu luyện!'
        );
    }
});

// Đăng nhập Discord bot
client.login(process.env.DISCORD_TOKEN || config.TOKEN);
