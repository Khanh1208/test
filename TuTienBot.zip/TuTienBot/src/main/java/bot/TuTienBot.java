
package bot;

import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

import javax.security.auth.login.LoginException;
import java.util.HashMap;
import java.util.Random;

public class TuTienBot extends ListenerAdapter {

    static class Player {
        int exp = 0;
        int level = 0;
        int linhThach = 0;
        int danDuoc = 0;
    }

    private final HashMap<String, Player> users = new HashMap<>();
    private final String[] realms = {
        "Phàm Nhân", "Luyện Khí", "Trúc Cơ", "Kim Đan",
        "Nguyên Anh", "Hóa Thần", "Đại Thừa", "Chân Tiên"
    };

    private String getRealm(int level) {
        int index = Math.min(level / 5, realms.length - 1);
        return realms[index];
    }

    @Override
    public void onMessageReceived(MessageReceivedEvent event) {
        if (event.getAuthor().isBot()) return;

        String content = event.getMessage().getContentRaw().toLowerCase();
        String userId = event.getAuthor().getId();

        switch (content) {
            case "/tu" -> {
                if (users.containsKey(userId)) {
                    event.getChannel().sendMessage("Bạn đã bắt đầu tu tiên rồi!").queue();
                } else {
                    users.put(userId, new Player());
                    event.getChannel().sendMessage("🧘 Bạn đã bước vào con đường tu tiên với cảnh giới **Phàm Nhân**.").queue();
                }
            }
            case "/trangthai" -> {
                if (!users.containsKey(userId)) {
                    event.getChannel().sendMessage("Bạn chưa bắt đầu tu tiên. Dùng `/tu` để khởi đầu.").queue();
                } else {
                    Player p = users.get(userId);
                    String msg = String.format(
                        "🌌 Cảnh giới: **%s**
💠 EXP: %d
💰 Linh thạch: %d
🧪 Đan dược: %d",
                        getRealm(p.level), p.exp, p.linhThach, p.danDuoc
                    );
                    event.getChannel().sendMessage(msg).queue();
                }
            }
            case "/tuluyen" -> {
                if (!users.containsKey(userId)) {
                    event.getChannel().sendMessage("Bạn chưa bắt đầu tu tiên. Dùng `/tu`.").queue();
                } else {
                    Player p = users.get(userId);
                    int gain = new Random().nextInt(11) + 5;
                    p.exp += gain;
                    if (p.exp >= 100) {
                        p.level += 1;
                        p.exp = 0;
                        String realm = getRealm(p.level);
                        event.getChannel().sendMessage("🎉 Bạn đã đột phá! Cảnh giới mới: **" + realm + "**").queue();
                    } else {
                        event.getChannel().sendMessage("Bạn tu luyện được " + gain + " EXP.").queue();
                    }
                }
            }
            case "/dokiep" -> {
                if (!users.containsKey(userId)) return;
                Player p = users.get(userId);
                if (p.level < 1 || p.exp < 50) {
                    event.getChannel().sendMessage("❌ Không đủ điều kiện độ kiếp (cần cấp ≥ 1 và EXP ≥ 50)!").queue();
                } else {
                    boolean success = new Random().nextInt(100) < 70;
                    if (success) {
                        p.level++;
                        p.exp = 0;
                        event.getChannel().sendMessage("⚡ Bạn đã vượt qua thiên kiếp! Tăng một cảnh giới!").queue();
                    } else {
                        p.exp -= 30;
                        event.getChannel().sendMessage("⚠️ Bạn thất bại khi độ kiếp, mất 30 EXP.").queue();
                    }
                }
            }
            case "/luyendan" -> {
                if (!users.containsKey(userId)) return;
                Player p = users.get(userId);
                int cost = 10;
                if (p.linhThach >= cost) {
                    p.linhThach -= cost;
                    p.danDuoc += 1;
                    event.getChannel().sendMessage("🧪 Bạn luyện thành công 1 đan dược!").queue();
                } else {
                    event.getChannel().sendMessage("❌ Không đủ linh thạch để luyện đan (cần 10).").queue();
                }
            }
            case "/timbao" -> {
                if (!users.containsKey(userId)) return;
                Player p = users.get(userId);
                int found = new Random().nextInt(20);
                p.linhThach += found;
                event.getChannel().sendMessage("📦 Bạn tìm thấy " + found + " linh thạch khi thám hiểm!").queue();
            }
            case "/banghoi" -> {
                event.getChannel().sendMessage("🏯 Hệ thống bang hội sẽ được mở trong tương lai!").queue();
            }
        }
    }

    public static void main(String[] args) throws LoginException {
        String token = "MTM3NjExODEwOTM3ODg0MjcxNA.GJoe_z.couePs-Z20OinT6slnVvvst-4d3m4oIzsSGHzQ";
        JDABuilder.createDefault(token)
                .addEventListeners(new TuTienBot())
                .build();
    }
}
